function perf=evalFuns(obs, sim, coef, model)
    perf=nan(size(model.evalFuns,1),1);
    
    for i0=1:size(model.evalFuns,1);
        try
            perf(i0)=model.evalFuns{i0}(obs,sim);
        catch err
            err=[];
            try
                perf(i0)=model.evalFuns{i0}(obs,sim,coef,model);
            catch err
                rethrow(err);
            end
        end
    end
end