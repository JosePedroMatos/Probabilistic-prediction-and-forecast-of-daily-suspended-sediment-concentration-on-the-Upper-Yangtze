%Mean absolute error
function performance = mae(observed, simulated)
    performance = sum(abs(observed-simulated))/length(observed);
end