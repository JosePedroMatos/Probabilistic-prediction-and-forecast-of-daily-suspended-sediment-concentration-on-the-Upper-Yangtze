function [perfTra, x0, lb, ub, sims]=evalMLP(x, model, varargin)
    persistent XTra;
    persistent yTra; 
    
    if nargin>=4
        XTra=varargin{1};
        yTra=varargin{2};
    end
    
    %% Return parameter information
    info=false;
    setPersistentOnly=false;
    for i0=4:2:size(varargin,2)
        switch varargin{i0-1}
            case 'info'
                info=logical(varargin{i0});
            case 'setPersistentOnly'
                setPersistentOnly=logical(varargin{i0});
            otherwise
                error(['Parameter unknown: ' varargin{i0-1} '.']);
        end
    end
        
    if (setPersistentOnly)
        perfTra=[];
        x0=[];
        lb=[];
        ub=[];
        sims=[];
        return;
    end
    
    if (info)
        perfTra=[];
%         perfVal=[];
        x0=ones(1, ...
            size(XTra,1)* model.nodes+ ...
            model.nodes * size(yTra,1) + ...
            model.nodes+ ...
            size(yTra,1) ...
            );

        if size(model.range,2)==1
            lb=x0*model.range(1,1);
            ub=x0*model.range(2,1);
        else
            if isnan(sum(model.range(:)))
                lb=x0*0;
                ub=x0*0;
                lb(end)=model.range(1,end);
                ub(end)=model.range(2,end);
            else
                lb=model.range(1,:);
                ub=model.range(2,:);
            end
        end
        if ~isfield(model,'x0')
            x0=randn(1,size(x0,2)).*(ub-lb)./4;
        else
            if length(model.x0)==1
                x0=x0*model.x0;
            else
                x0=model.x0;
            end
        end
        tmp=x0<lb; x0(tmp)=lb(tmp);
        tmp=x0>ub; x0(tmp)=ub(tmp);
        
        return
    else
        x0=[];
        lb=[];
        ub=[];
    end

    %% Perform calculations
    nObj=size(model.evalFuns,1);
    
    nIW=size(XTra,1)*model.nodes;
    sIW=[model.nodes size(XTra,1)];
    nLW=model.nodes;
    nb1=model.nodes;
    if isfield(model,'netFuns')
        funLay1=str2func(model.netFuns{1});
        funLay2=str2func(model.netFuns{2});
    else
        funLay1=str2func('tansig');
        funLay2=str2func('purelin');
    end
    perfTra=nan(nObj,size(x,2));
%     perfVal=nan(nObj,size(x,2));
    argumentsOut=nargout;
    if argumentsOut==5
        sims=nan(size(x,2),size(yTra,2));
    end
    for i0=1:size(model.evalFuns,1)
        if ischar(model.evalFuns{i0});
            model.evalFuns{i0}=str2func(model.evalFuns{i0});
        end
    end
    if isfield(model,'nonNegative')
        nonNegative=logical(model.nonNegative);
        threshold=model.nonNegative;
    else
        nonNegative=false;
    end
    
    parfor i0=1:size(x,2)
%     for i0=1:size(x,2)
        xTmp=x(:,i0)';

        IW=reshape(xTmp(1:nIW),sIW(1),sIW(2)); xTmp(1:nIW)=[];
        LW=xTmp(1:nLW); xTmp(1:nLW)=[];
        b1=xTmp(1:nb1)'; xTmp(1:nb1)=[];
        b2=xTmp';
        
        yEstTra=netSim(XTra,IW,LW,b1,b2,funLay1,funLay2);
        if (nonNegative)
            yEstTra(yEstTra<threshold)=threshold;
        end
        if argumentsOut==5
            sims(i0,:)=yEstTra;
        end
        %%%%% CORRECTED AFTER MARWAN'S WORK %%%%%
%         perfTra(:,i0)=evalFuns(yTra,yEstTra,[IW(:); LW(:); b1(:); b2(:)],model);
        perfTra(:,i0)=evalFuns(yTra,yEstTra,[IW(:); LW(:)],model);
    end
end