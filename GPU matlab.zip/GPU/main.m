function [traPeriods, valPeriods, tesPeriods, groupIdxs]=main(varargin)
%% Read inputs
    try
        fourierCoefs=21;
        data=[];
        fadingMemoryParameters=[0 0.79432823];
        groupsGamma=0.008;
        groupIdxs=[];
        groupCustom=0;
        groupNumber=1;
        savePeriod=10;
        epochs=200;
        leadTimes=[];
        population=4000;
        saveFolder=[];
        tesFraction=0.30;
        valFraction=0.30;
        model=[];
        plots=1;
        valPeriods=[];
        tesPeriods=[];
        genFun='[fourier extra fadingMemoryLags(outputs, inputGen.leadTime, inputGen.fadingMemoryParameters)];';
        for i0=2:2:size(varargin,2)
            switch varargin{i0-1}
                case 'valPeriods'
                    valPeriods=varargin{i0};
                case 'tesPeriods'
                    tesPeriods=varargin{i0};
                case 'fourierCoefs'
                    fourierCoefs=varargin{i0};
                case 'data'
                    data=varargin{i0};
                case 'fadingMemoryParameters'
                    fadingMemoryParameters=varargin{i0};
                case 'groupsGamma'
                    groupsGamma=varargin{i0};
                case 'groupIdxs'
                    groupIdxs=varargin{i0};
                    groupCustom=1;
                case 'groupNumber'
                    groupNumber=varargin{i0};
                case 'savePeriod'
                    savePeriod=varargin{i0};
                case 'epochs'
                    epochs=varargin{i0};    
                case 'leadTime'
                    leadTimes=varargin{i0};
                case 'population'
                    population=varargin{i0};
                case 'saveFolder'
                    saveFolder=varargin{i0};
                case 'tesFraction'
                    tesFraction=varargin{i0};
                case 'valFraction'
                    valFraction=varargin{i0};
                case 'model'
                    model=varargin{i0};
                case 'plots'
                    plots=varargin{i0};
                case 'genFun'
                    genFun=varargin{i0};
                otherwise
                    error(['Parameter unknown: ' varargin{i0-1} '.']);
            end
        end
    catch err
        rethrow(err);
    end
    
    %% Validate and post-process inputs
    try
        if isempty(data)
            error('Flow data structure needed (''data'' parameter).');
        end
        
        if isempty(leadTimes)
            error('Lead times vector needed (''leadTimes'' parameter).');
        end
        
        if isempty(model)
            error('A model strucutre is needed (''model'' parameter).');
        end
        
        if isempty(groupIdxs)
            groupIdxs={1:data.period};
        end
        
        period=data.period;
    catch err
        rethrow(err);
    end
    
    %% Pre-process series
    data=preprocessInputs(data);
    
    %% Organize according to period
    try
        perTime=mod(data.time,period)+1;
        [idxs]=find(perTime==1);
        
        if idxs(1)~=1
            idxs=[1; idxs];
        end
        if idxs(end)~=perTime(end)
            idxs=[idxs; size(perTime,1)];
        end
        
        perSeries=cell(size(idxs,1)-1,1);
        for i0=1:size(idxs,1)-1
            perSeries{i0,1}.values=data.values(idxs(i0):idxs(i0+1)-1,1);
            perSeries{i0,1}.time=perTime(idxs(i0):idxs(i0+1)-1,1);
            perSeries{i0,1}.oriTime=data.time(idxs(i0):idxs(i0+1)-1,1);
        end
    catch err
        rethrow(err);
    end
    
    %% Automatically find groups
    try
        if (~groupCustom && groupNumber~=1)
            % aggregate data
            tmpAllPeriods=nan(size(perSeries,1),period);
            tmpTime=cellfun(@(x) x.time, perSeries,'UniformOutput',false);
            tmpValues=cellfun(@(x) x.values, perSeries,'UniformOutput',false);
            for i0=1:size(tmpAllPeriods,1)
                tmpAllPeriods(i0,tmpTime{i0})=tmpValues{i0};
            end
            
            % clear missing periods and average the remaining missing data
            tmpAllPeriods(sum(isnan(tmpAllPeriods),2)==size(tmpAllPeriods,2),:)=[];
            tmp=repmat(nanmean(tmpAllPeriods,1),size(tmpAllPeriods,1),1);
            tmpAllPeriods(isnan(tmpAllPeriods))=tmp(isnan(tmpAllPeriods));
            
            % sort, normalize and keep principal components
            tmpAllPeriods=sort(tmpAllPeriods);
            tmp=ones(size(tmpAllPeriods))*min(tmpAllPeriods(:));
            tmpAllPeriods=(tmpAllPeriods-tmp)./(ones(size(tmpAllPeriods))*(max(tmpAllPeriods(:))-min(tmpAllPeriods(:))));
            [coefs, score, latent] = princomp(tmpAllPeriods');
            numberToKeep=max([3 find(cumsum(latent)/sum(latent)>=0.8,1,'first')]);
            score=score(:,1:numberToKeep)';
            score=score.*repmat((latent(1:numberToKeep)/max(latent)),1,size(score,2));
            
            % add distance information
            toCluster=[cos((1:period)*2*pi/period)*1.5;...
                sin((1:period)*2*pi/period)*1.5;...
                score];

            [clusters, ~, clusterDist] = kmeans(toCluster', groupNumber, 'distance', 'sqEuclidean');
            for i0=1:5
                [tmpCuster, ~, tmpDist] = kmeans(toCluster', groupNumber, 'distance', 'sqEuclidean');
                if sum(tmpDist.^2)<sum(clusterDist.^2)
                    clusters=tmpCuster;
                    clusterDist=tmpDist;
                end
            end
            
            % smooth clusters
            tmpIdxs=[1:3*period]';
            tmpClusters=[clusters; clusters; clusters];
            smoothedClusters=zeros(period, groupNumber);
            for i0=1:groupNumber
                centers=find(tmpClusters==i0);
                for i1=1:size(centers,1)
                    tmpDist=centers(i1)-tmpIdxs;
                    rbf=exp(-groupsGamma/50*(tmpDist).^2);
                    smoothedClusters(:,i0)=smoothedClusters(:,i0)+rbf(period+1:2*period,1);
                end
            end
            [~, smoothedClusters]=max(smoothedClusters,[],2);
            
            % build indexes
            groupIdxs=cell(groupNumber,1);
            for i0=1:groupNumber
                groupIdxs{i0}=find(smoothedClusters==i0)';
            end
        end
    catch err
        rethrow(err);
    end
    
    %% Prepare groups
    try
        tmpTime=[1:period 1:period 1:period]';
        tmpIdxs=[1:size(tmpTime,1)]';
        
        groups=zeros(period,length(groupIdxs));
        for i0=1:length(groupIdxs)
            for i1=groupIdxs{i0}
                centers=find(tmpTime==i1);
                for i2=1:size(centers,1)
                    tmpDist=centers(i2)-tmpIdxs;
                    rbf=exp(-groupsGamma*(tmpDist).^2);
                    groups(:,i0)=groups(:,i0)+rbf(period+1:2*period,1);
                end
            end
        end
        groups=groups/max(groups(:));
        groups(groups<0.001)=0;
    catch err
        rethrow(err);
    end    
        
    %% Divide in training, validation and test
    try
        
        % select validation and test periods
        allPeriods=[1:size(perSeries,1)]';
        traPeriods=allPeriods;
        traPeriods=traPeriods(~ismember(traPeriods, valPeriods));
        traPeriods=traPeriods(~ismember(traPeriods, tesPeriods));
        if isempty(valPeriods)
            tmp=randperm(size(traPeriods,1));
            valPeriods=sort(traPeriods(tmp(1:round(size(allPeriods,1)*valFraction))));
            traPeriods=traPeriods(~ismember(traPeriods,valPeriods));
        end
        if isempty(tesPeriods)
            tmp=randperm(size(traPeriods,1));
            tesPeriods=sort(traPeriods(tmp(1:round(size(allPeriods,1)*tesFraction))));
            traPeriods=traPeriods(~ismember(traPeriods,tesPeriods));
        end
        
        % aggregate series
        tmpSeries=perSeries(traPeriods,1);
        tmp=cellfun(@(x) x.values, tmpSeries,'UniformOutput',false);
        validSeriesTra.values=cell2mat(tmp);
        tmp=cellfun(@(x) x.time, tmpSeries,'UniformOutput',false);
        validSeriesTra.time=cell2mat(tmp);
        tmp=cellfun(@(x) x.oriTime, tmpSeries,'UniformOutput',false);
        validSeriesTra.oriTime=cell2mat(tmp);
        
        traTime=validSeriesTra.oriTime;
        valTime=cell2mat(cellfun(@(x) x.oriTime, perSeries(valPeriods,1), 'UniformOutput',false));
        tesTime=cell2mat(cellfun(@(x) x.oriTime, perSeries(tesPeriods,1), 'UniformOutput',false));
    catch err
        rethrow(err); 
    end
    
    %% Fit Fourier series
    try 
        fFourierSimple=@(x, y) fFourier(x, y, period, fourierCoefs);
        fourierSeries=fFourierSimple(validSeriesTra.time(~isnan(validSeriesTra.values(:,1))), ...
            validSeriesTra.values((~isnan(validSeriesTra.values(:,1))),:)); 
    
    catch err
        rethrow(err);
    end
    
    %% Plot Fourier
    try
        if (plots)
            %Check maximum recorded flow value
            maxFlow=max(data.values);
            tmp=max([round(log10(maxFlow))-1 0]);
            maxFlowAxis=round(maxFlow/10^tmp)*10^tmp;

            figure(150);

            %plot groups
            colorSet=gray(size(groups, 2)+1);
            colorSet=colorSet(1:size(groups,2), :);
            colorSet=colorSet(randperm(size(groups, 2)), :);
            hold on;
            for i0=1:size(groups,2)
                fill(0:period+1, [0; groups(:,i0)*maxFlowAxis*0.6; 0], colorSet(i0, :), 'edgecolor', colorSet(i0, :), 'facealpha', 0.2);
            end
            hold off;

            %Data
            hold on;
            plot(validSeriesTra.time, validSeriesTra.values, '.k');
            hold off;
            
            %Fourier
            hold on;
            plot(1:period, fourierSeries, '-red', 'LineWidth', 2);
            hold off;
           
        end
    catch err
        rethrow(err);
    end
    
    %% Main
    try
        for i0=1:length(leadTimes)
            % prepare lagged input data
            
            outputs=data.values;
            extra=data.extra;
            
            inputGen.period=period;
            inputGen.fourier=fourierSeries;
            inputGen.cycle=[cos([1:period]'/period*(2*pi)) sin([1:period]'/period*(2*pi))];
            inputGen.groups=groups;
            inputGen.leadTime=leadTimes(i0);
            inputGen.fadingMemoryParameters=fadingMemoryParameters;
            inputGen.reference=0;
            inputGen.function=genFun;
            
            fourier=inputGen.fourier(perTime,:);
            cycle=inputGen.cycle(perTime,:);
            
            inputs=eval(inputGen.function);
            
            toKeep=~isnan(sum(inputs,2)) & ~isnan(sum(outputs,2));
            traLogi=toKeep & ismember(data.time,traTime);
            valLogi=toKeep & ismember(data.time,valTime);
            tesLogi=toKeep & ismember(data.time,tesTime);
            
            % ZScores
            tmpGroups=inputGen.groups(perTime,:);
            inputGenGroups=cell(size(tmpGroups,2),1);
            for i0=1:size(tmpGroups,2)
                [~, muOut, sOut] = zscore(outputs(traLogi & tmpGroups(:,i0)~=0,:));
                [~, muIn, sIn] = zscore(inputs(traLogi & tmpGroups(:,i0)~=0,:));
                inputGen.scaOut.mu=muOut;
                inputGen.scaOut.sd=sOut;
                inputGen.scaOut.function=@(x) (x-repmat(inputGen.scaOut.mu,size(x,1),1))./repmat(inputGen.scaOut.sd,size(x,1),1);
                inputGen.scaOut.inverse=@(x) x.*repmat(inputGen.scaOut.sd,size(x,1),1)+repmat(inputGen.scaOut.mu,size(x,1),1);
                inputGen.scaIn.mu=muIn;
                inputGen.scaIn.sd=sIn;
                inputGen.scaIn.function=@(x) (x-repmat(inputGen.scaIn.mu,size(x,1),1))./repmat(inputGen.scaIn.sd,size(x,1),1);
                inputGen.scaIn.inverse=@(x) x.*repmat(inputGen.scaIn.sd,size(x,1),1)+repmat(inputGen.scaIn.mu,size(x,1),1);
                inputGenGroups{i0}=inputGen;
            end
            
            %run the optimization routine
            if isempty(saveFolder)
                saveFolder=mainBands(outputs,...
                    model,...
                    inputGenGroups,...
                    perTime,...
                    'extra', extra,...
                    'training',traLogi,...
                    'validation',valLogi,...
                    'test',tesLogi,...
                    'epochs',epochs,...
                    'population',population,...
                    'saveFolder',saveFolder,...
                    'dates', data.date...
                    );
            else
                mainBands(outputs,...
                    model,...
                    inputGenGroups,...
                    perTime,...
                    'extra', extra,...
                    'training',traLogi,...
                    'validation',valLogi,...
                    'test',tesLogi,...
                    'epochs',epochs,...
                    'population',population,...
                    'saveFolder',saveFolder,...
                    'savePeriod', savePeriod,...
                    'dates', data.date...
                    );
            end
        end
    catch err
        rethrow(err);
    end
end