function [saveFolder]=mainBands(outputs, model, inputGenGroups, indexes, varargin);


    %% Add paths
    addpath([pwd filesep 'amalgamCustom']);
    addpath([pwd filesep 'shadedPlot']);

    %% Pre-process inputs
    tmp0=randperm(size(outputs,1))';
    traLogi=false(size(outputs,1),1);

    traLogi(tmp0(1:round(size(traLogi,1)*0.6)),1)=true;
    valLogi=~traLogi;
    tesLogi=false(size(traLogi));
    saveFolder='';
    savePeriod=[];
    epochs=150;
    population=4000;
    extra=[];
    dates=[];
    detQuantiles=[];%[0.01 0.25 .75 0.99];
    for i0=2:2:size(varargin,2)
        switch varargin{i0-1}
            case 'training'
                traLogi=logical(varargin{i0});
            case 'validation'
                valLogi=logical(varargin{i0});
            case 'test'
                tesLogi=logical(varargin{i0});
            case 'saveFolder'
                saveFolder=varargin{i0};
            case 'savePeriod'
                savePeriod=varargin{i0};
            case 'epochs'
                epochs=varargin{i0};
            case 'population'
                population=varargin{i0};
            case 'extra'
                extra=varargin{i0};
            case 'detQuantiles'
                detQuantiles=varargin{i0};
            case 'dates'
                dates=varargin{i0};
                %             case ''
                %                 =varargin{i0};
            otherwise
                error(['Parameter unknown: ' varargin{i0-1} '.']);
        end
    end
    if isempty(savePeriod)
        savePeriod=round(epochs/5);
    end

    %% Prepare inputs, outputs, and groups
    groupNumber=size(inputGenGroups{1}.groups,2);
    zInGroups=cell(groupNumber,1);
    zOutGroups=cell(groupNumber,1);
    modelGroups=cell(groupNumber,1);
    for i0=1:groupNumber
        inputGen=inputGenGroups{i0};
        
        groups=inputGen.groups(indexes,:);
        fourier=inputGen.fourier(indexes,:);
        cycle=inputGen.cycle(indexes,:);
        inputs=eval(inputGen.function);
        
        zOut=inputGen.scaOut.function(outputs);
        zIn=inputGen.scaIn.function(inputs);
        
        if isfield(model,'nonNegative')
            nonNegative=logical(model.nonNegative);
            if (nonNegative)
                model.nonNegative=-inputGen.scaOut.mu/inputGen.scaOut.sd;
            end
        end
        
        zInGroups{i0}=zIn;
        zOutGroups{i0}=zOut;
        modelGroups{i0}=model;
    end

    %% Start saving data
    saveDateStr=datestr(now(),'yyyy.mmm.dd HH.MM');
    if isempty(saveFolder)
        matlabFolder=pwd;
        cd([pwd filesep '..']);
        saveDirDefault=[pwd filesep 'results' filesep saveDateStr];
        cd(matlabFolder);
        if ~exist(saveFolder,'dir')
            mkdir(saveDirDefault);
        end
        saveFolder = uigetdir(saveDirDefault,'Choose result directory.');
        if saveFolder==0
            error(['No folder selected. Calculation stopped.']);
        end
        if ~isequal(saveDirDefault,saveFolder)
            tmp=dir(saveDirDefault);
            if size(tmp,1)<=2
                try
                    rmdir(saveDirDefault);
                end
            end
        end
    else
        if ~exist(saveFolder,'dir')
            
            mkdir(saveFolder);
        end
    end

    clear i0 nanLogic siz valFrac tmp0 tmp1 varargin
    save([saveFolder filesep num2str(inputGen.leadTime,'%03u') '_' 'baseData.mat'], 'inputGenGroups', 'indexes', 'modelGroups', 'outputs', 'traLogi', 'valLogi', 'tesLogi', 'extra', 'dates');

    %% Prepare model
    modelFunction=[];
    evalc(['modelFunction=@' model.function]);
    [~, x0, lb, ub]=modelFunction([], modelGroups{1}, zInGroups{1}', zOutGroups{1}', 'info' ,true);

    %% Main
    for i0=1:groupNumber
        inputGen=inputGenGroups{i0};
        groups=inputGen.groups(indexes,:);
        model=modelGroups{i0};
        
        groupIndex=groups(:,i0)~=0;

        inTra=zInGroups{i0}(groupIndex & traLogi,:);
        inVal=zInGroups{i0}(groupIndex & valLogi,:);
        outTra=zOutGroups{i0}(groupIndex & traLogi,:);
        outVal=zOutGroups{i0}(groupIndex & valLogi,:);

        extraAmalgam.bPoint=[];

        prefix=[num2str(inputGen.leadTime,'%03u') '_' num2str(i0,'%03u')];

        %Retrieve higher lead time chromosomes
        tmpFiles=arrayfun(@(x) x.name,dir([saveFolder filesep '*_*_*.mat']),'UniformOutput',false);
        tmp=cellfun(@(x) regexp(x,'_|\.| ','split'),tmpFiles,'UniformOutput',false);
        tmpLead=cellfun(@(x) str2double(x{1}),tmp);
        tmpGroup=cellfun(@(x) str2double(x{2}),tmp);
        tmpIter=cellfun(@(x) str2double(x{8}),tmp);

        completedLeadTimes=unique(tmpLead);
        tmp=completedLeadTimes-inputGen.leadTime;
        tmp(tmp<=0)=NaN;
        [~, id]=min(tmp);

        extraAmalgam.Initial=[];
        if ~isempty(id)
            %completed lead time and group
            chosenIds=tmpLead==completedLeadTimes(id(1)) & i0==tmpGroup;
            if sum(chosenIds)==0
                %same lead time and group
                chosenIds=tmpLead==tmpLead(id(1)) & i0==tmpGroup;
                if sum(chosenIds)==0
                    %closer group and same lead time
                    [~, id]=min((tmpGroup-i0).^2);
                    chosenIds=tmpLead==tmpLead(id(1)) & tmpGroup(id(1))==tmpGroup;
                    if sum(chosenIds)==0
                        chosenIds=tmpLead==tmpLead(id(1)) & tmpGroup(id(1))==tmpGroup;
                    end
                end
            end
            if sum(chosenIds)~=0
                [~, id]=max(tmpIter(chosenIds));
                tmp=tmpFiles(chosenIds);
                chosenFile=tmp(id(1));

                nonExceedanceFractionDeviation=load([saveFolder filesep chosenFile{:}],'nonExceedanceFractionDeviation');
                nonExceedanceFractionDeviation=nonExceedanceFractionDeviation.nonExceedanceFractionDeviation;
                [~, minId]=min(nonExceedanceFractionDeviation(:,2));
                minVal=min([nonExceedanceFractionDeviation(end,1) max([10 nonExceedanceFractionDeviation(minId,1)])]);
                minVal=find(nonExceedanceFractionDeviation(:,1)>=minVal,1,'first');
                
                chosenFile=tmp{minVal,:};
                tmp=load([saveFolder filesep chosenFile],'fullParGen');
                if size(x0,2)==size(tmp.fullParGen,2)
                    disp([chosenFile ' used as starting point...']);
                    extraAmalgam.Initial=tmp.fullParGen;
                end
            end
        end

        try
            % Run the AMALGAM optimization code
            extraAmalgam.BoundHandling = 'Bound';
            extraAmalgam.Alg = {'PSO','AMS','PSO','PSO'};
            
            extraAmalgam.SavePeriod=savePeriod;
            extraAmalgam.SaveFolder=saveFolder;
            extraAmalgam.SaveSuffix=[prefix '_' saveDateStr];

            extraAmalgam.nPars=length(x0);                     % number of parameters to be optimized
            inopts.n=length(x0);                        % dimension of the problem
            inopts.N=population;                      % size of the population
            inopts.ndraw=inopts.N*epochs;               % maximum number of function evaluations
            inopts.nobj=size(model.evalFuns,1);                              % number of objectives
            inopts.q=size(extraAmalgam.Alg,2);                 % number of algorithms
            inopts.tempFileName=[extraAmalgam.SaveFolder filesep 'AMALGAM ' extraAmalgam.SaveSuffix '.mat'];

            parRange.minn=lb;                           % minimum parameter boundary
            parRange.maxn=ub;                           % maximum parameter boundary

            [outputs,...
                ParGen,...
                ObjVals,...
                ParSet...
                ] = AMALGAM_bands(...
                inopts,...                              % AMALGAM options
                model.function,...                          % name of objective/fitness function
                parRange,...                            % parameter boundaries
                [],...                                  % true Pareto front is not available
                extraAmalgam,...                        % extra parameters for the several optimization methods
                inTra', ...                             % arguments passed to objective function
                outTra', ...
                inVal', ...
                outVal', ...
                model ...
                );

            delete(inopts.tempFileName);
        catch err
            rethrow(err);
        end

    end
end