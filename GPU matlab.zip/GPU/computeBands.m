function [struOut, bandResults]=computeBands(param, modelFunction, bandRanges, bands, varargin)

    %% Perform simulations
	[objVal, ~, ~, ~, simsVal] = modelFunction(param',varargin{[5 3 4]},5);
	[objTra, ~, ~, ~, simsTra] = modelFunction(param',varargin{[5 1 2]},5);
    
    %% Get band means
    bandResults=nan(size(simsTra,2)+size(simsVal,2),size(bandRanges,2));
    for i0=1:size(bandRanges,2)
        tmp=objTra(1,:)>=bandRanges(1,i0) & objTra(1,:)<=bandRanges(2,i0);
        bandResults(1:size(simsTra,2),i0)=mean(simsTra(tmp,:),1);
        bandResults(size(simsTra,2)+1:end,i0)=mean(simsVal(tmp,:),1);
    end
    
    %% Interpolate missing data
    filledBandResults=nan(size(bandResults));
    parfor i0=1:size(bandResults,1)
%     for i0=1:size(bandResults,1)
        tmpBaseValues=bandResults(i0,:);
        if sum(~isnan(tmpBaseValues))>=2
            tmp=tmpBaseValues(1,end);
            for i1=size(tmpBaseValues,2)-1:-1:1
                if isnan(tmp)
                    tmp=tmpBaseValues(1,i1);
                else
                    if round(tmp*1E6)==round(tmpBaseValues(1,i1)*1E6)
                        tmpBaseValues(1,i1)=NaN;
                    else
                        tmp=tmpBaseValues(1,i1);
                    end
                end
            end
            tmp=isnan(tmpBaseValues);
            sorted=sort(tmpBaseValues(1,~tmp),'ascend');
            tmpValues=interp1(bands(~tmp),sorted,bands,'linear','extrap');
        else
            tmpValues=tmpBaseValues;
        end
        filledBandResults(i0,:)=tmpValues;
    end
    bandResults=filledBandResults;
    
    %% Compute error metrics
    traLogi=[ones(size(simsTra,2),1); zeros(size(simsVal,2),1)]==1;
    tesLogi=~traLogi;
    [pValuesTra, pValuesTes, unifDistTra, unifDistTes]=predictiveQQPlot([varargin{2} varargin{4}]',bandResults,traLogi,tesLogi, bands);
    
    %alpha (overall reliability)
    alphaTra=1-2*mean(abs(pValuesTra-unifDistTra));
    alphaTes=1-2*mean(abs(pValuesTes-unifDistTes));
    
    %xi (range)
    tmp=zeros(size(pValuesTra));
    tmp(pValuesTra==0 | pValuesTra==1)=1;
    xiTra=1-mean(tmp);
    tmp=zeros(size(pValuesTes));
    tmp(pValuesTes==0 | pValuesTes==1)=1;
    xiTes=1-mean(tmp);
    
    %pi (resolution)
    bandProb=bandRanges(2,:)-bandRanges(1,:);
    expected=sum(bandResults.*repmat(bandProb,size(bandResults,1),1),2)./sum(bandProb);
    expSqr=sum(bandResults.^2.*repmat(bandProb,size(bandResults,1),1),2)./sum(bandProb);
    piAbsTra=mean(1./(expSqr(traLogi)-expected(traLogi).^2).^0.5);
    piAbsTes=mean(1./(expSqr(tesLogi)-expected(tesLogi).^2).^0.5);
    
    piRelTra=mean(abs(expected(traLogi))./(expSqr(traLogi)-expected(traLogi).^2).^0.5);
    piRelTes=mean(abs(expected(tesLogi))./(expSqr(tesLogi)-expected(tesLogi).^2).^0.5);

    struOut.perf.alpha.tra=alphaTra;
    struOut.perf.alpha.tes=alphaTes;
    struOut.perf.xi.tra=xiTra;
    struOut.perf.xi.tes=xiTes;
    struOut.perf.piAbs.tra=piAbsTra;
    struOut.perf.piAbs.tes=piAbsTes;
    struOut.perf.piRel.tra=piRelTra;
    struOut.perf.piRel.tes=piRelTes;
    
    %CRPS (continuous rank probability score)
    struOut.perf.cprs.tra=crps(varargin{2}', bandResults(traLogi,:), bands);
    struOut.perf.cprs.tes=crps(varargin{4}', bandResults(tesLogi,:), bands);
    
    [~, tmp]=min(objTra(2,:));
    struOut.perf.cprsBest.tra=crps(varargin{2}', simsTra(tmp,:)');
    struOut.perf.cprsBest.tes=crps(varargin{4}', simsVal(tmp,:)');
    
end