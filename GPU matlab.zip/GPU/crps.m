function perf=crps(obs, sim, prob)

    if nargin<3
        prob=linspace(0, 1, 2+size(sim,2));
        prob=prob(2:end-1);
    end
    
    sim=sort(sim,2);
    tmp=~isnan(sum(sim,2)) & ~isnan(obs);
    sim=sim(tmp,:);
    obs=obs(tmp,:);
    
    range=[min([sim(:); obs(:)]) max([sim(:); obs(:)])];
    bins=linspace(range(1), range(2), 10000);
    dX=bins(2)-bins(1);
    
    perf=nan(size(obs,1),1);
    parfor i0=1:size(obs,1)
        x=unique([bins obs(i0)]);
        if size(sim,2)>1
            [tmpCDF, ia]=unique(sim(i0,:));
            tmpProb=prob(ia);

            CDF = interp1(tmpCDF,tmpProb,x,'linear','extrap');
            CDF(CDF<0)=0;
            CDF(CDF>1)=1;
        else
            CDF=zeros(size(x));
            CDF(x>=sim(i0,:))=1;
        end
        F0=zeros(size(CDF));
        F0(x>=obs(i0))=1;
            
        perf(i0)=sum((CDF-F0).^2)*dX;
    end
    perf=mean(perf);
end