function dataOut=preprocessInputs(dataIn)
    
    dataOut=dataIn;
    
    if ~isfield(dataIn,'extra')
        dataIn.extra=nan(size(dataIn.values,1),0);
    end
    
    switch dataIn.period
        case 365
            % remove 29th February
            if strcmp(dataIn.timeUnit,'day')==1
                extendedTime=[dataIn.time(1):dataIn.time(end)]';
                extendedValues=nan(size(extendedTime,1),size(dataIn.values,2));
                extendedValues(ismember(extendedTime,dataIn.time),:)=dataIn.values;
                extendedExtraValues=nan(size(extendedTime,1),size(dataIn.extra,2));
                extendedExtraValues(ismember(extendedTime,dataIn.time),:)=dataIn.extra;
                
                %crop 366th day
                idxs=month(extendedTime)==2 & day(extendedTime)==29;
                extendedTime(idxs,:)=[];
                extendedValues(idxs,:)=[];
                extendedExtraValues(idxs,:)=[];
               
                %prepareReference
                [~, reference]=ismember(dataIn.reference,   extendedTime);
                counter=[1:size(extendedTime,1)]';
                counter=counter-counter(reference); %the reference is the 0.
                
                dataOut.values=extendedValues;
                dataOut.extra=extendedExtraValues;
                dataOut.time=counter;
                dataOut.date=extendedTime;
%                 dataOut.reference=0;
                dataOut.timeUnit='correctedDay';
            end
        otherwise
            
    end

end