% Function that takes on a row-oriented matrix of series and concatenates it with
% (possibly) lagged (possibly) time-faded transformations  

function Y=fadingMemoryLags(X, timeLags, fadingBetas)
%     Y=fadingMemoryLags([[1 1000]'*cumsum(ones(1,100))]', [0 10], [0 0.8]);

    %% Input consistency verification
    if isempty(timeLags)
        timeLags=0;
    end
    if isempty(fadingBetas)
        fadingBetas=0;
    end
    
    %% Creating fading-memory series
    if isequal(fadingBetas,0)
        filteredX=X;
    else
        filteredX=nan(size(X,1),size(X,2)*length(fadingBetas));
        filteredX(1,:)=repmat(X(1,:),1,length(fadingBetas));
        tmpFadingBetas=reshape(repmat(fadingBetas,size(X,2),1),1,[]);
        lastUsableData=filteredX(1,:);
        for i0=2:size(X,1)
            filteredX(i0,:)=lastUsableData+(1-tmpFadingBetas).*(repmat(X(i0,:),1,length(fadingBetas))-lastUsableData);
            tmp0=filteredX(i0,:);
            if sum(isnan(tmp0))~=0
                tmp1=repmat(X(i0,:),1,length(fadingBetas));
                filteredX(i0,isnan(tmp0))=tmp1(isnan(tmp0));
            end    
            lastUsableData=filteredX(i0,:);
        end
    end
    
    %% Creating time-lagged series
    timeLaggedX=nan(size(filteredX,1),size(filteredX,2)*length(timeLags));
    for i0=1:length(timeLags)
        tmpIndexes=[1:size(filteredX,2)]+(i0-1)*size(filteredX,2);
        timeLaggedX(:,tmpIndexes)=[nan(max(timeLags(i0),0),size(filteredX,2)); ...
            filteredX(max(-timeLags(i0)+1,1):min(size(timeLaggedX,1)-timeLags(i0),size(timeLaggedX,1)),:);...
            nan(max(-timeLags(i0),0),size(filteredX,2))];
    end
    
    Y=timeLaggedX;
end