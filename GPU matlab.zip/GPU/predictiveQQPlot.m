function [pValuesTra, pValuesTes, unifDistTra, unifDistTes]=predictiveQQPlot(output, bandResults, traLogi, testLogi, bands)
    pValues=nan(size(bandResults,1),1);
    tmpBandResults=flipdim(bandResults,2);
    for i1=1:size(bandResults,1)
        if ~isnan(sum(tmpBandResults(i1,:)))
            [tmpCDF, ia]=unique(tmpBandResults(i1,:));
            tmpBands=bands(ia);
            pValues(i1) = interp1(tmpCDF,tmpBands,output(i1),'pchip','extrap');
        else
            pValues(i1)=NaN;
        end
    end
    pValues(pValues>1)=1;
    pValues(pValues<0)=0;

    [pValuesTra]=sort(pValues(traLogi));
    unifDistTra=[0:size(pValuesTra)-1]'/(size(pValuesTra,1)-1);

    [pValuesTes]=sort(pValues(testLogi));
    unifDistTes=[0:size(pValuesTes)-1]'/(size(pValuesTes,1)-1);

    if sum(traLogi)>1
        plot(unifDistTra,pValuesTra,'-black'); hold on;
    end
    plot(unifDistTes,pValuesTes,'-k', 'LineWidth', 1.5); hold on;
    axis([0 1 0 1]);
    axis square;
    grid;
    xlabel('Theoretical Quantile of U[0,1]','FontSize',9,'FontName','Times New Roman');
    ylabel('Quantile of observed p-values','FontSize',9,'FontName','Times New Roman');
    plot([0 1],[0 1],':black');
    title('Predictive QQ plot');
    legend('Training', 'Test');

    hold off;
end