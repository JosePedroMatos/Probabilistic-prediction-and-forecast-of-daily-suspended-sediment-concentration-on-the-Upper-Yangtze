function shadePlotBands(obs, bandData, dates, varargin)
    
    set(gcf, 'InvertHardcopy','off','Color',[1 1 1]);

    if nargin<3 || isempty(dates)
        dates=[1:size(bandData,1)]';
    end

    nBands=size(bandData,2);
    nPlots=floor(nBands/2);
    handles=NaN(0,1);
    for i0=1:nPlots
        plotData=bandData(:,[i0 (end-i0+1)]);
        validData=~isnan(sum(plotData,2));
        plotData=plotData(validData,:);
        plotDates=dates(validData);
        validDates=[1; plotDates(2:end)-plotDates(1:end-1)];
        breaks=find(validDates~=1);
        if isempty(breaks)
            breaks=size(validDates,1);
        else
            if breaks(end)~=size(validDates,1)
                breaks=[breaks; size(validDates,1)];
            end
        end
        tmp=1;
        for i1=1:size(breaks,1)
            try
            h=shadedplot(plotDates(tmp:breaks(i1)-1)', ...
                            plotData(tmp:breaks(i1)-1,1)', ...
                            plotData(tmp:breaks(i1)-1,end)', ...
                            i0/nPlots*[1 1 1],'black'); hold all;
                        
            if i1==1
                handles=[handles; h];
            end
            catch
            end
            tmp=breaks(i1);
            
        end
    end
                        
    h=plot(dates, obs, '.', 'Color', [204 102 0]/255);
    handles=[handles; h(1)];
    hold off;
    
       if size(varargin,2)>0
        bands=varargin{1,1};
        covered=nan(1,size(bands,2)/2);
        for i0=1:size(covered,2)
            covered(i0)=-bands(i0)+bands(end-i0+1);
        end
        labels=[cellstr(num2str(covered'*100,'%.0f%%')); {'Obs.'}];
        legend(handles, labels, 'FontSize',8,'FontName','Times New Roman', 'Orientation', 'horizontal', 'location','northoutside');
       end
    
    xlabel('Date (gaps indicate discontinuities)','FontSize',9,'FontName','Times New Roman')
    ylabel('Prediction (z-scores)','FontSize',9,'FontName','Times New Roman')
    
     set(gca, 'FontSize',9,'FontName','Times New Roman','Position',[0.08 0.15 0.9 0.7]);
    xlim('auto');
end