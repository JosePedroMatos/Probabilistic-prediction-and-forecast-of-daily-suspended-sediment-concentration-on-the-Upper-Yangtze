clear all
clc

for i = 1:28

fid = fopen('simcopy.csh','r');
fid2 = fopen(['simcopy' num2str((i-1)*1000+1) '_' num2str(i*1000) '.csh'],'w');
	for k = 1:2
		temp = fgets(fid);
		fprintf(fid2,'%s',temp)
	end
	for k = 1:2
		temp = fgets(fid);
	end
		fprintf(fid2,'set sfold = %d\n',(i-1)*1000 + 1);
	fprintf(fid2,'set efold = %d\n',i*1000);		
	while feof(fid) == 0
		temp = fgets(fid);
		fprintf(fid2,'%s',temp);
	end
end
