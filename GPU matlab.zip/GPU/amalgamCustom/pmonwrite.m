function pmonwrite(ptype,ploadest)

%% Write the monthly sediment load that will be used for calibration
fid1 = fopen([ptype '_mon_loadest.dat'],'w');
st_yr = 2001;
end_yr = 2005;

k = 1;
for curr_yr = st_yr:end_yr
    
    for Mon = 1:12
        pload_mon(curr_yr-st_yr+1,Mon) = 0;
        for dayno = 1:max(max(calendar(curr_yr,Mon)));
            pload_mon(curr_yr-st_yr+1,Mon) = ...
                pload_mon(curr_yr-st_yr+1,Mon) + ploadest(k);
            
            k = k + 1;
        end
        fprintf(fid1,'%f\t',pload_mon(curr_yr-st_yr+1,Mon));
    end
    fprintf(fid1,'\n');
end
fclose(fid1);
