function gw(hruid,par_n,par_f,x)
hruid=char(hruid);
hru_str=[hruid '.gw'];
ALPHA_BF=x(par_n==14);
GW_DELAY=x(par_n==15);
GW_REVAP=x(par_n==16);
GWQMN=x(par_n==17);
REVAPMN=x(par_n==51);
delete(hru_str);

fid1=fopen(['../sensin/' hru_str],'r');
fid2=fopen(hru_str,'w');

L=0;
while feof(fid1)==0;
      L=L+1;
      line=fgets(fid1);
      if L==6 && par_f(par_n==17)==1;
         fprintf(fid2,'%16.4f    %s\n',GWQMN,'| GWQMN : Threshold depth of water in the shallow aquifer required for return flow to occur [mm]');
      elseif L==7 && par_f(par_n==16)==1;
         fprintf(fid2,'%16.4f    %s\n',GW_REVAP,'| GW_REVAP : Groundwater "revap" coefficient');
      elseif L==4 && par_f(par_n==15)==1;
         fprintf(fid2,'%16.4f    %s\n',GW_DELAY,'| GW_DELAY : Groundwater delay [days]');
      elseif L==5 && par_f(par_n==14)==1;
         fprintf(fid2,'%16.4f    %s\n',ALPHA_BF,'| ALPHA_BF : BAseflow alpha factor [days]');          
      elseif L==8 && par_f(par_n==51)==1;
               fprintf(fid2,'%16.4f    %s\n',REVAPMN,'| REVAPMN: Threshold depth of water in the shallow aquifer for "revap" to occur [mm]');
      else
         fprintf(fid2,'%s',line); 
      end
end
fclose(fid1);
fclose(fid2);
return;
