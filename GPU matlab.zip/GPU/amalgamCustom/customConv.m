function [delta, dispersion, centroid] = customConv(AMALGAMPar, varargin)
    
    %% Dispersion of the population
    tmp=repmat(permute(AMALGAMPar,[1 3 2]),[1 size(AMALGAMPar,1) 1]);
    tmp=(tmp-permute(tmp,[2 1 3])).*repmat(triu(ones(size(tmp,1),size(tmp,2))),[1 1 size(tmp,3)]);
    tmp=sum(tmp.^2,3).^0.5;
    dispersion=sum(tmp(:))/sum(1:size(tmp,1));
    
    %% Norm of the population centroid
    centroid=norm(mean(AMALGAMPar),2);
    
    %% Difference between the last two iterations' dispersion.
    if nargin==2
        delta=abs(dispersion-varargin{1});
    else
        delta=NaN;
    end
    
end