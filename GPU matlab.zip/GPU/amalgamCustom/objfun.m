%% This script compute the objective function for calibration 
function OF = objfun(par_n,par_f,x,icall,fid_sce,fid_err)
global outlets w_errors
%% Alter model parameters
par_alter(par_n,par_f,x);
%% Call the SWAT model
dos('swat2005.exe');
%% Read the "output.rch" file
fid1 = fopen('output.rch','r');
fid2 = fopen('rchout.prn','w');
L = 0;
while feof(fid1) == 0
    L = L+1;
    line = fgets(fid1);
    if L >= 10
        [reach,rem] = strtok(line);
        fprintf(fid2,'%s\n',rem);
    end
end
fclose(fid1);
fclose(fid2);
out = load('rchout.prn');
%% Compute error statistics for outlets of interest
for i = 1:length(outlets)    
    [swat_out] = read_output(out,outlets(i));
    Stats = statistics(swat_out,outlets(i)); 
    fprintf(fid_err,'%-7i%-8i',icall,outlets(i));
    all_stats = [Stats.RE;Stats.BIAS;Stats.R2;Stats.NS;Stats.RMSE];
    error_stats(:,i) = [Stats.BFR/100;all_stats(:)]; 
    fprintf(fid_err,'%s\n',sprintf('%-10.4f',error_stats(:,i))); 
    % -----------------------------------------
    of_stats(:,i) = [Stats.BFR/100,1-Stats.NS]; 
    % -----------------------------------------
end
%% Compute objective function for calibration
OF = sum((w_errors * of_stats) / (sum(w_errors)) / length(outlets));
%% Display icall and objective function value
disp(['ICALL = ' num2str(icall)])
disp(['OF = ' num2str(OF)])
%% Print parameter values and objective function in sce_out.txt file
x = x(par_f(:) ~= 0);
sce_out = [x OF];
fprintf(fid_sce,'%s\n',sprintf('%-15.5f',sce_out));
%% Plot the objective function 
figure(1)
plot(icall,OF,'.','MarkerSize',5)
% ylim([0 5])
hold on
return