clear all
clc
global VarName
sim_n=2;
n_sub=22; % Number of subwatersheds in the project setup.


[x0 par_f bl bu] = textread('../user_inputs/par_file.prn','%*d %*s %*s %*s %f %d %f %f',...
    'headerlines',2);
nPars = 61;
par_f = ones(nPars,1);
par_n = (1:nPars)';
nRuns = 500;

RandStream.setDefaultStream (RandStream('mt19937ar','seed',1));
RandNums = rand(nRuns,nPars);

VarName = {'Flow(cms)';'Org N(kg)';'NO3N(kg)';'NH4N(kg)';'NO2N(kg)';...
    'TN(kg)';'Org P(kg)';'Min P(kg)';'TP(kg)';'Sediment(tons)';...
    'Sol. Pst.(mg/L)';'Sor. Pst.(mg/L)';'Pesticide(mg/L)'};
iVars = [1];
outlet = 21;
start_year = 2001;
n_years = 5;
fid = fopen('../user_inputs/Runs.dat','a+');
fprintf(fid,'RunNum\tR2\tRNS2\n');
%fid2 = fopen('../user_inputs/bestpar4.dat','w');
x = load('../user_inputs/bestpar4.dat');
for iRun = 455 %1:nRuns
    
   
%     for iPar = 1:nPars
%         x(iPar,1) = bl(iPar)+(bu(iPar)-bl(iPar))*RandNums(iRun,iPar);
%     	fprintf(fid2,'%.7f\n',x(iPar,1));
%     end

    file_id = id_func(n_sub);
    par_alter(par_n,par_f,x);
    ! ./swat
    rchproc(iVars,n_sub,outlet,start_year,n_years);
outstats = calstats(outlet);
fid = fopen('../user_inputs/Runs.dat','a+');
fprintf(fid,'%d\t%.2f\t%.2f\n',iRun,outstats.R2flow,outstats.R2NSflow);
end

%dlmwrite('../user_inputs/bestpar2.dat',x)
