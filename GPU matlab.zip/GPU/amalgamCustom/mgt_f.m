function mgt_f(hruid,hru_lnd,par_n,par_f,x)
hruid=char(hruid);
hru_str=[hruid '.mgt'];

BIOMIX=x(par_n==23);
CN2_f=x(par_n==24);
USLE_P=x(par_n==25);
DDRAIN=x(par_n==56);
TDRAIN=x(par_n==57);
GDRAIN=x(par_n==58);
delete(hru_str);

fid1=fopen(['../sensin/' hru_str],'r');
fid2=fopen(hru_str,'w');

L=0;
while feof(fid1)==0;
    L=L+1;
    line=fgets(fid1);
    if L==10 && par_f(par_n==23)==1;
        fprintf(fid2,'%16.2f\t  %s\n',BIOMIX,'| BIOMIX: Biological mixing efficiency');
    elseif L==11 && par_f(par_n==24)==1;
        CN2=str2num(strtok(line))*(1+CN2_f); 
        fprintf(fid2,'%16.2f\t  %s\n',CN2,'| CN2: Initial SCS CN II value');
    elseif L==12 && strcmp(hru_lnd,'Row Crops')==1 && par_f(par_n==25)==1;
        fprintf(fid2,'%16.2f\t  %s\n',USLE_P,'| USLE_P: USLE support practice factor');
    elseif L==25 && par_f(par_n==56)==1;
        fprintf(fid2,'%16.2f\t  %s\n',DDRAIN,'| DDRAIN: depth to subsurface tile drain (mm)');
    elseif L==26 && par_f(par_n==57)==1;
        fprintf(fid2,'%16.2f\t  %s\n',TDRAIN,'| TDRAIN: time to drain soil to field capacity (hr)');
    elseif L==27 && par_f(par_n==58)==1;
        fprintf(fid2,'%16.2f\t  %s\n',GDRAIN,'| GDRAIN: drain tile lag time (hr)');
    else
        fprintf(fid2,'%s',line);
    end
end
fclose(fid1);
fclose(fid2);
return;
