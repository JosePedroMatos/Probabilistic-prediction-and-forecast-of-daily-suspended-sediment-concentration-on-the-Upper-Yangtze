%function fin_mat=rchtosim

outlet = 27;
start_year = 1997;
n_years = 5;
fid1=fopen('output.rch','r');

fid2=fopen(['sim_daily' num2str(outlet) '.dat'],'w');
fprintf(fid2,'Year\tDay\tFlow\n');
for i=1:1:9
    temp=fgets(fid1);
end

for i=1:1:(outlet-1)
    temp=fgets(fid1);
end

k=1;
for j=1:n_years
    tmp_yrPst = 0;
    yr_now = start_year +j -1;
    if rem(yr_now,4)==0
        no_days = 366;
    else
        no_days = 365;
    end
    for day_n=1:no_days
        temp1=fgets(fid1);

        str_flow = temp1(39:49);
        flow(k,1) = str2num(str_flow);

%         str_solPst = temp1(52:62);
%         str_sorPst = temp1(64:74);

%         solPst(k,1) = str2num(str_solPst);
%         sorPst(k,1) = str2num(str_sorPst);

%         if flow(k,1)==0
%             totPst(k,1) = 0;
%            
%         else
%             totPst(k,1) = (solPst(k,1) + sorPst(k,1))/flow(k,1)/86400;%mg/cubmet to ug/L
%             
%         end
        
        for i=1:1:198
            if feof(fid1)==0
                temp=fgets(fid1);
            end
        end
%         tmp_yrPst = tmp_yrPst + totPst(k,1);
        fprintf(fid2,'%d\t%d\t%f\n',yr_now,day_n,flow(k,1));
          k=k+1;
    end
    
          
%     avg_yrPst(j,1)=tmp_yrPst/no_days;
end
fclose(fid1);
fclose(fid2);
% avg_Pst = mean(avg_yrPst);
% fin_mat={solPst sorPst totPst avg_Pst avg_yrPst};
fin_mat=[];





