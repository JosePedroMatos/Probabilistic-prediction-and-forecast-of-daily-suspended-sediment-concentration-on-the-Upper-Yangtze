function OF = CalcOF(ModPred,Measurement,Extra);
% Calculate the objective function
global outlet

%StartDate = simdata(1,2) -1 + datenum(simdata(1,1),1,1);
sse = 0;
for oidx = 1:length(outlet)
    obsdata = Measturement.MeasData(:,oidx);
    simdata = ModPred(:,oidx);
    ObsSim = [obsdata simdata];
    ObsSim = ObsSim(~isnan(ObsSim(:,end-1)),:);
    sse = sse + sum((obsdata-simdata).^2);
    NS(oidx) = 1 - sum((obsdata - simdata).^2)/sum((obsdata - mean(obsdata)).^2);
end

OF.sse = sse;
OF.NS = NS;
%OF(1) = -(1-sumsqr((ModPred-obsdata))/sumsqr(obsdata-mean(obsdata)));

