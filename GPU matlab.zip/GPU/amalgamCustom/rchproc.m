function rchproc(iVars,nsubs,outlet)
global VarName OutVar
% GEt the dates of the simulation
dates_all = proj_dates;
n_years = dates_all(end,1)-dates_all(1,1)+1;
outlet = sort(outlet);
fid1=fopen('output.rch','r');

temp = fgets(fid1);
for i=1:1:9
    temp=fgets(fid1);
    if size(findstr(temp,'FLOW_OUTcms'),1)>0
        break;
    end
end
ColNums = zeros(1,10);
for idx = 1:size(iVars,2)

    if iVars(idx) == 1
        ColNums(1) = findstr(temp,'FLOW_OUTcms')+length('FLOW_OUTcms');
    elseif  min(((2:6) - iVars(idx)).^2) == 0 % 6. Total Nitrogen (Org N + NO3N + NH3N + NO2N)
        ColNums(2) = findstr(temp,'ORGN_OUTkg')+length('ORGN_OUTkg');
        ColNums(3) = findstr(temp,'NO3_OUTkg')+length('NO3_OUTkg');
        ColNums(4) = findstr(temp,'NH4_OUTkg')+length('NH4_OUTkg');
        ColNums(5) = findstr(temp,'NO2_OUTkg')+length('NO2_OUTkg');
    elseif min(((7:9) - iVars(idx)).^2) == 0 % 9. Total Phosphorus (Org P + Min P)
        ColNums(6) = findstr(temp,'ORGP_OUTkg')+length('ORGP_OUTkg');
        ColNums(7) = findstr(temp,'MINP_OUTkg')+length('MINP_OUTkg');
    elseif iVars(idx) == 10
        ColNums(8) = findstr(temp,'SED_OUTtons')+length('SED_OUTtons');
    elseif min(((11:13) - iVars(idx)).^2) == 0 % 13. Total Pesticide (SOLPST + SORPST)
        ColNums(9) = findstr(temp,'SOLPST_OUTmg')+length('SOLPST_OUTmg');
        ColNums(10) = findstr(temp,'SORPST_OUTmg')+length('SORPST_OUTmg');
    end
end

Q_m=zeros(n_years,12,length(outlet));OrgN_m=zeros(n_years,12,length(outlet));NO3N_m = zeros(n_years,12,length(outlet));
NH4N_m = zeros(n_years,12,length(outlet));NO2N_m = zeros(n_years,12,length(outlet));TN_m = zeros(n_years,12,length(outlet));
OrgP_m = zeros(n_years,12,length(outlet));MinP_m = zeros(n_years,12,length(outlet));TP_m = zeros(n_years,12,length(outlet));
OutVar_m = zeros(n_years*12,13,length(outlet));

for i=1:1:(outlet(1)-1)
    temp=fgets(fid1);
end
for k = 1:size(dates_all,1)

    for oidx = 1:length(outlet)
        temp1=fgets(fid1);
        try
            Yidx = dates_all(k,1); 
        catch
            eidx = 1;
        end
        midx = dates_all(k,2);
        didx = dates_all(k,3);
        for idx = 1:size(iVars,2)
            flag = zeros(1,5);
            if iVars(idx) == 1 && flag(1) == 0
                try
                    Q(k,1) = str2num(temp1(ColNums(1)-10:ColNums(1)-1));
                catch
                    eidx = 1;
                end
                try
                    OutVar(k,1,oidx) = Q(k,1);
                catch
                    eidx = 1;
                end
                %             OutVar_m((Yidx-1)*12+midx,1) = OutVar_m((Yidx-1)*12+midx,1) + OutVar(k,1)/...
                %                 eomday(Yidx+start_year,midx);
                flag(1) = 1;
            elseif min(((2:6) - iVars(idx)).^2) == 0 && flag(2) == 0 % 6. Total Nitrogen (Org N + NO3N + NH3N + NO2N)
                OrgN(k,1) = str2num(temp1(ColNums(2)-10:ColNums(2)-1));
                NO3N(k,1) = str2num(temp1(ColNums(3)-10:ColNums(3)-1));
                NH4N(k,1) = str2num(temp1(ColNums(4)-10:ColNums(4)-1));
                NO2N(k,1) = str2num(temp1(ColNums(5)-10:ColNums(5)-1));
                TN(k,1) = OrgN(k,1) + NO3N(k,1) + NH4N(k,1) + NO2N(k,1);
                OutVar(k,2:6,oidx) = [OrgN(k,1) NO3N(k,1) NH4N(k,1) NO2N(k,1) TN(k,1)];
                OutVar_m((Yidx-1)*12+midx,2:6,oidx) = OutVar_m((Yidx-1)*12+midx,2:6,oidx) + OutVar(k,2:6,oidx);
                flag(2) = 1;
            elseif min(((7:9) - iVars(idx)).^2) == 0 && flag(3) == 0 % 9. Total Phosphorus (Org P + Min P)
                OrgP(k,1) = str2num(temp1(ColNums(6)-10:ColNums(6)-1));
                MinP(k,1) = str2num(temp1(ColNums(7)-10:ColNums(7)-1));
                TP(k,1) = OrgP(k,1) + MinP(k,1);
                OutVar(k,7:9,oidx) = [OrgP(k,1) MinP(k,1) TP(k,1)];
                OutVar_m((Yidx-1)*12+midx,7:9,oidx) = OutVar_m((Yidx-1)*12+midx,7:9,oidx) + OutVar(k,7:9,oidx);
                flag(3) = 1;
            elseif iVars(idx) == 10 && flag(4) == 0
                Sed(k,1) = str2num(temp1(ColNums(8)-10:ColNums(8)-1));
                OutVar(k,10,oidx) = Sed(k,1);
                OutVar_m((Yidx-1)*12+midx,10,oidx) = OutVar_m((Yidx-1)*12+midx,10,oidx) + OutVar(k,10,oidx);
                flag(4) = 1;
            elseif min(((11:13) - iVars(idx)).^2) == 0 && flag(5) == 0 % 13. Total Pesticide (SOLPST + SORPST)
                SolPst(k,1) = str2num(temp1(ColNums(9)-10:ColNums(9)-1));
                SorPst(k,1) = str2num(temp1(ColNums(10)-10:ColNums(10)-1));
                TPst(k,1) = (SolPst(k,1) + SorPst(k,1))/Q(k,1)/86400;%mg/cubmet to ug/L
                OutVar(k,11:13,oidx) = [SolPst(k,1) SorPst(k,1) TPst(k,1)];
                OutVar_m((Yidx-1)*12+midx,11:13,oidx) = OutVar_m((Yidx-1)*12+midx,11:13,oidx) + OutVar(k,11:13,oidx);
                flag(5) = 1;
            end

        end
        if oidx < length(outlet)
            for i=1:outlet(oidx+1)-outlet(oidx)-1
                if feof(fid1)==0
                    temp=fgets(fid1);
                end
            end
        elseif oidx == length(outlet)
            for i = 1:nsubs-outlet(oidx)+outlet(1)-1
                if feof(fid1) == 0
                    temp = fgets(fid1);
                end
            end 
        end

    end
end

fclose(fid1);


%% Ptrint the daily and monthly simulated files
for oidx = 1:length(outlet)
    fid2=fopen(['sim_daily' num2str(outlet(oidx)) '.dat'],'w');
    fid3=fopen(['sim_month' num2str(outlet(oidx)) '.dat'],'w');
    fprintf(fid2,'Year\tMonth\tDay');
    fprintf(fid3,'Year\tMonth');

    for vidx = 1:size(iVars,2)
        fprintf(fid2,'\t%s',VarName{iVars(vidx)});
        fprintf(fid3,'\t%s',VarName{iVars(vidx)});
    end
    for idx = 1:size(dates_all,1)
        fprintf(fid2,'\n');
        fprintf(fid2,'%d\t%d\t%d',dates_all(idx,1),dates_all(idx,2),dates_all(idx,3));
        for vidx = 1:size(iVars,2)
            fprintf(fid2,'\t%.4f',OutVar(idx,iVars(vidx),oidx));
        end
    end
end
eidx = 1; 
% for Yidx = 1:n_years
%
%     for midx = 1:12
%         for d2idx = 1:eomday(start_year+Yidx-1,midx)
%             fprintf(fid2,'\n');
%             fprintf(fid2,'%d\t%d',start_year+Yidx-1,d2idx);
%             for vidx = 1:size(iVars,2)
%                 fprintf(fid2,'\t%.4f',OutVar(didx,iVars(vidx)));
%             end
%             didx = didx + 1;
%         end
%     end
%
% end
% m2idx = 1;
% for Yidx = 1:n_years
%
%     for midx = 1:12
%         fprintf(fid3,'\n');
%         fprintf(fid3,'%d\t%d',start_year+Yidx-1,midx);
%         for vidx = 1:size(iVars,2)
%             fprintf(fid3,'\t%.4f',OutVar_m(m2idx,iVars(vidx)));
%         end
%         m2idx = m2idx + 1;
%     end
%
% end



fclose all;







