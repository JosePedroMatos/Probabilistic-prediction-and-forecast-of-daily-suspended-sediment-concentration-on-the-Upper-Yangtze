function [ploadest,pconcest] = loadestproc(ptype,pmonwriteflag)

% You will have to run the loadestformat and then run the loadest to get
% the following coefficients

%% Read flow data in cms
% fdata -> [year month day flow(cms)]
fdata = nanfill(ptype);

% Convert flow into cfs to use it in the equations obtained by the Loadest
% model
fdata(:,4) = fdata(:,4)/0.02832;


%% Calculate the concentration (loadconc) and load estimated by Loadest
%% per day (sload)
if findstr(ptype,'TSS') > 0
    c_lnQ = 5.2378;
    lnQ = log(fdata(:,4)) - c_lnQ;
    kgpd2mgps = 10^6/24/60/60;
    coeff = [8.4969    1.4330    0.2748];
    flcms = fdata(:,4)*0.02832; % convert flow back to cms
    ploadest =exp(coeff(1) + coeff(2)*lnQ + coeff(3)*lnQ.^2);
    pconcest =exp(coeff(1) + coeff(2)*lnQ + coeff(3)*lnQ.^2)*...
        kgpd2mgps./flcms/1000;
elseif findstr(ptype,'TP') > 0
    %     c_lnQ = 5.0815;
    %     coeff = [3.8697    0.8504    0.2108];
    c_lnQ = 5.04;
    coeff = [4.5836    0.5888    0.2892];

    c_dt = 2002.489;
    lnQ = log(fdata(:,4)) - c_lnQ;
    kgpd2mgps = 10^6/24/60/60;
    
    k_yr = 1;
    for yr = 2001:2005
        if rem(yr,4) == 0
            dinyr = 366;
        else
            dinyr = 365;
        end
        for dy = 1:dinyr
            dtime(k_yr,1) = yr + dy/dinyr - c_dt;
            k_yr = k_yr +1;
        end
    end
    flcms = fdata(:,4)*0.02832; % convert flow back to cms
    ploadest = exp(coeff(1) + coeff(2)*lnQ + coeff(3)*lnQ.^2);
    pconcest = exp(coeff(1) + coeff(2)*lnQ + coeff(3)*lnQ.^2)*kgpd2mgps./flcms/1000;
    
elseif findstr(ptype,'TN') > 0
    %     c_lnQ = 5.0977;
    %     coeff = [7.8277    1.0680    0.003];%For the 2nd Order model
    
    c_lnQ = 5.0786;
    coeff = [7.9854    1.2658   -0.0486];%For the 2nd Order model
    
    c_dt = 2002.499;
    lnQ = log(fdata(:,4)) - c_lnQ;
    kgpd2mgps = 10^6/24/60/60;
    
    k_yr = 1;
    for yr = 2001:2005
        if rem(yr,4) == 0
            dinyr = 366;
        else
            dinyr = 365;
        end
        for dy = 1:dinyr
            dtime(k_yr,1) = yr + dy/dinyr - c_dt;
            k_yr = k_yr +1;
        end
    end
    flcms = fdata(:,4)*0.02832; % convert flow back to cms
    ploadest = exp(coeff(1) + coeff(2)*lnQ + coeff(3)*lnQ.^2);
    pconcest = exp(coeff(1) + coeff(2)*lnQ + coeff(3)*lnQ.^2)*kgpd2mgps./flcms/1000;
end




if pmonwriteflag == 1
    pmonwrite(ptype,ploadest);
end




