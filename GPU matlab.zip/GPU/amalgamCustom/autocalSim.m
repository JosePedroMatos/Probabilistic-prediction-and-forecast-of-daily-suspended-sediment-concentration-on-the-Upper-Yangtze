clear all
clc
global VarName
copyfile('../../autocal/sensin/goodpar.out','../outputs/','f');
cd ../outputs
parAutocal = [25    22    21    18    27    55     9    24    50   52 ...
    28    54     6     9    30    15    16    17    14    26    31   53];
VarName = {'Flow(cms)';'Org N(kg)';'NO3N(kg)';'NH4N(kg)';'NO2N(kg)';...
    'TN(kg)';'Org P(kg)';'Min P(kg)';'TP(kg)';'Sediment(tons)';...
    'Sol. Pst.(mg/L)';'Sor. Pst.(mg/L)';'Pesticide(mg/L)'};
fid1 = fopen('goodpar.out','r');
L = 1;
while feof(fid1)== 0
    temp = fgets(fid1);
    for idx = 1:size(parAutocal,2)
        RunNo(L) = str2num(temp(1:5));
        goodpar(L,idx) = str2num(temp(5+(idx-1)*12+1:5+(idx)*12));
    end
    L = L + 1;
end

sim_n=2;
n_sub=36; % Number of subwatersheds in the project setup.
outlets=[26]; % Number of outlets of interest in the project setup.
fid = fopen('../outputs/AutocalParSim12.dat','a+');
fprintf(fid,'RunNo\tR^2\tR^2_NS\n');
iVars = [1];

start_year = 2006;
n_years = 2;

%for iRun = 1:size(goodpar,1)
cd(['../sim' num2str(sim_n)])

par_n = (1:55)';
par_f = zeros(55,1);
x = zeros(55,1);

cd ..
! rm -r sim2

! tar xvf sensin1.tar
! mv sensin1 sim2
! cp user_inputs/* sim2
! cp P_files_new/* sim2
cd sim2
par_f(parAutocal) = 1;
x(parAutocal) = goodpar(12,:);%using 12 instead of iRun to simulate 12 parameters
file_id = id_func(n_sub);
par_alter(par_n,par_f,x');
! ./swat
rchproc(iVars,n_sub,outlets,start_year,n_years);
outstats = calstats(outlets);
fid = fopen('../outputs/AutocalParSim12.dat','a+');
fprintf(fid,'%d\t%.2f\t%.2f\n',iRun,outstats.R2flow,outstats.R2NSflow);

%end
fclose(fid);
