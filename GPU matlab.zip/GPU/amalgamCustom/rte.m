function rte(subid,par_n,par_f,x)
subid=char(subid);
subid=[subid '.rte'];
CH_COV=x(par_n==26); 
CH_KII=x(par_n==27);
CH_NII=x(par_n==28);
CH_SII=x(par_n==29);
CH_KIIautocal = x(par_n == 59);
delete(subid);

fid1=fopen(['../sensin/' subid],'r');
fid2=fopen(subid,'w');

L=0;
while feof(fid1)==0;
    L=L+1;
    line=fgets(fid1);
    if L==6 && par_f(par_n==28)==1;
        fprintf(fid2,'%14.3f\t  %s\n',CH_NII,'| CH_N2 : Manning"s nvalue for main channel');
    elseif L==4 && par_f(par_n==29)==1;
        CH_S2=str2num(strtok(line))*(1+CH_SII); %#ok<ST2NM>
        fprintf(fid2,'%14.3f\t  %s\n', CH_S2,'| CH_S2 : Main channel slope [m/m]');        
    elseif L==7 && par_f(par_n==27)==1;
        fprintf(fid2,'%14.3f\t  %s\n',CH_KII,'| CH_K2 : Effective hydraulic conductivity [mm/hr]');   
    elseif L==7 && par_f(par_n==59)==1;
        fprintf(fid2,'%14.3f\t  %s\n',CH_KII*(1+CH_KIIautocal),'| CH_K2 : Effective hydraulic conductivity [mm/hr]');   
    elseif L==9 && par_f(par_n==26)==1;
        fprintf(fid2,'%14.3f\t  %s\n',CH_COV,'| CH_COV : Channel cover factor');         
    else
        fprintf(fid2,'%s',line);
    end
end
fclose(fid1);
fclose(fid2);

return;
