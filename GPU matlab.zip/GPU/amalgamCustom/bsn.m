function bsn(par_n,par_f,x)
CMN=x(par_n==1);
NPERCO=x(par_n==2);
PERCOP=x(par_n==3);
PPERCO=x(par_n==4);
RSDCO=x(par_n==5);
SFTMP=x(par_n==6);
SPCON=x(par_n==7);
SPEXP=x(par_n==8);
SURLAG=x(par_n==9);
ESCO=x(par_n==18);
SMFMX=x(par_n==54);
TIMP =x(par_n==55);

delete('basins.bsn')

fid1=fopen('../sensin/basins.bsn','r');
fid2=fopen('basins.bsn','w');

L=0;
while feof(fid1)==0;
    L=L+1;
    line=fgets(fid1);
    if L==5 && par_f(par_n==54)==1;
        fprintf(fid2,'%16.3f\t  %s\n',SMFMX,'| SMFMX : Melt factor for snow on June 21 [mm H2O/�C-day]');          
    elseif L==4 && par_f(par_n==6)==1;
        fprintf(fid2,'%16.3f\t  %s\n',SFTMP,'| SFTMP : Snowfall temperature [�C]');          
    elseif L==8 && par_f(par_n==55)==1;
        fprintf(fid2,'%16.3f\t  %s\n',TIMP,'| TIMP : Snow pack temperature lag factor');          
    elseif L==13 && par_f(par_n==18)==1;
        fprintf(fid2,'%16.3f\t  %s\n',ESCO,'| ESCO: soil evaporation compensation factor');
    elseif L==20 && par_f(par_n==9)==1;
        fprintf(fid2,'%16.3f\t  %s\n',SURLAG,'| SURLAG : Surface runoff lag time [days]');
    elseif L==23 && par_f(par_n==7)==1;
        fprintf(fid2,'%16.5f\t  %s\n',SPCON,'| SPCON : Linear parameter for calculating sediment reentrained');
    elseif L==24 && par_f(par_n==8)==1;
        fprintf(fid2,'%16.5f\t  %s\n',SPEXP,'| SPEXP : Exponent parameter for calculating sediment reentrained in channel sediment routing');
    elseif L==27 && par_f(par_n==1)==1;
        fprintf(fid2,'%16.4f\t  %s\n',CMN,'| CMN : Rate factor for humus mineralization of active organic nitrogen');  
    elseif L==30 && par_f(par_n==2)==1;
        fprintf(fid2,'%16.3f\t  %s\n',NPERCO,'| NPERCO : Nitrogen percolation coefficient');  
    elseif L==31 && par_f(par_n==4)==1;
        fprintf(fid2,'%16.3f\t  %s\n',PPERCO,'| PPERCO : Phosphorus percolation coefficient');  
    elseif L==34 && par_f(par_n==5)==1;
        fprintf(fid2,'%16.3f\t  %s\n',RSDCO ,'| RSDCO : Residue decomposition coefficient');         
    elseif L==36 && par_f(par_n==3)==1;
        fprintf(fid2,'%16.3f\t  %s\n',PERCOP,'| PERCOP : Pesticide percolation coefficient');  
    else
        fprintf(fid2,'%s',line);
    end
end
fclose(fid1);
fclose(fid2);
return;
