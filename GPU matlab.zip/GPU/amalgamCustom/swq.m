function swq(subid,par_n,par_f,x)

subid=char(subid);
subid=[subid '.swq'];
RS2=x(par_n==36); 
RS3=x(par_n==37);
RS4=x(par_n==38);
RS5=x(par_n==39);
BC1=x(par_n==40); 
BC2=x(par_n==41);
BC3=x(par_n==42);
BC4=x(par_n==43);

delete(subid);

fid1=fopen(['../sensin/' subid],'r');
fid2=fopen(subid,'w');

L=0;
while feof(fid1)==0;
    L=L+1;
    line=fgets(fid1);
    if L==4 && par_f(par_n==36)==1;
        fprintf(fid2,'%16.3f\t  %s\n',RS2,'| RS2:	Benthic (sediment) source rate for dissolved phosphorus in the reach at 20�C [mg dissolved P/[m2�day]]');
    elseif L==5 && par_f(par_n==37)==1;
        fprintf(fid2,'%16.3f\t  %s\n',RS3,'| RS3:	Benthic source rate for NH4-N in the reach at 20�C [mg NH4-N/[m2�day]]');       
    elseif L==6 && par_f(par_n==38)==1;
        fprintf(fid2,'%16.3f\t  %s\n',RS4,'| RS4:	Rate coefficient for organic N settling in the reach at 20�C [day-1]');
    elseif L==7 && par_f(par_n==39)==1;
        fprintf(fid2,'%16.3f\t  %s\n',RS5,'| RS5:	Organic phosphorus settling rate in the reach at 20�C [day-1]');
    elseif L==16 && par_f(par_n==40)==1;
        fprintf(fid2,'%16.3f\t  %s\n',BC1,'| BC1:	Rate constant for biological oxidation of NH4 to NO2 in the reach at 20� C [day-1]');       
    elseif L==17 && par_f(par_n==41)==1;
        fprintf(fid2,'%16.3f\t  %s\n',BC2,'| BC2:	Rate constant for biological oxidation of NO2 to NO3 in the reach at 20� C [day-1]');
    elseif L==18 && par_f(par_n==42)==1;
        fprintf(fid2,'%16.3f\t  %s\n',BC3,'| BC3:	Rate constant for hydrolysis of organic N to NH4 in the reach at 20� C [day-1]');
    elseif L==19 && par_f(par_n==43)==1;
        fprintf(fid2,'%16.3f\t  %s\n',BC4,'| BC4:	Rate constant for mineralization of organic P to dissolved P in the reach at 20� C [day-1]');
    else
        fprintf(fid2,'%s',line);
    end
end
fclose(fid1);
fclose(fid2);

return;
