function sol(hruid,par_n,par_f,x)
hruid=char(hruid);
hru_str=[hruid '.sol'];

SOL_AWC=x(par_n==30);
SOL_K=x(par_n==31);
USLE_K=x(par_n==32);
SOL_Z=x(par_n==53);
delete(hru_str);
path_input=['../sensin/' hru_str];

fid1=fopen(path_input,'r');
fid2=fopen(hru_str,'w');
L=0;
while feof(fid1)==0;
      L=L+1;
      line=fgets(fid1);
      if L==8 && par_f(par_n==53)==1;
         SOLZ_new = str2num(sscanf(line,'%*27c%[^\n]')) .* (1+SOL_Z);
         fprintf(fid2,' Depth                [mm]:%s\n',sprintf('%12.2f',SOLZ_new)); 
      elseif L==10 && par_f(par_n==30)==1;
         AWC_new = str2num(sscanf(line,'%*27c%[^\n]')) .* (1+SOL_AWC);
         fprintf(fid2,' Ave. AW Incl. Rock Frag  :%s\n',sprintf('%12.2f',AWC_new)); 
      elseif L==11 && par_f(par_n==31)==1;
         Ksat_new = str2num(sscanf(line,'%*27c%[^\n]')) .* (1+SOL_K);
         fprintf(fid2,' Ksat. (est.)      [mm/hr]:%s\n',sprintf('%12.2f',Ksat_new));    
      elseif L==18 && par_f(par_n==32)==1;
         USLEK_new = str2num(sscanf(line,'%*27c%[^\n]')) .* (1+USLE_K); 
         fprintf(fid2,' Erosion K                :%s\n',sprintf('%12.2f',USLEK_new)); 
      else
         fprintf(fid2,'%s',line); 
      end
end
fclose(fid1);
fclose(fid2);
return;
