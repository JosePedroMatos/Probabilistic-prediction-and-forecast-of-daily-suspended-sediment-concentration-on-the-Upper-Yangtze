function OF = CalcOF(ModPred,Measurement,~)
% Calculate the objective function
global outlet AMALGAMPar reservoir

%StartDate = simdata(1,2) -1 + datenum(simdata(1,1),1,1);
sse = 0;
Biastot=0;
Biastotp=0;
NStot=0;
VolR=0;
NStotp=0;
VolRp=0;
SSEt=0;
for oidx = 1:length(outlet)
    obsdata = Measurement.MeasData(:,oidx);
    simdata = ModPred(:,oidx);
    ObsSim = [obsdata simdata];
    ObsSim = ObsSim(~isnan(ObsSim(:,end-1)),:);
    Obs = ObsSim(:,1);
    Sim = ObsSim(:,2);
    %%Theo modified OF
    sse(oidx) = sum(abs(Obs-Sim)./Obs)/length(Obs);
    bias(oidx)=sum((Sim-Obs)./Obs)/length(Obs);
    NS(oidx) = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2);
    W(oidx)=size(ObsSim,1);
    Vol(oidx)=sum(Sim)/sum(Obs);
end

if ~isempty(reservoir)
    for oidx=length(outlet)+1:length(outlet)+length(reservoir)
        obsdata = Measurement.MeasData(:,oidx);
        simdata = ModPred(:,oidx);
        ObsSim = [obsdata simdata];
        ObsSim = ObsSim(~isnan(ObsSim(:,end-1)),:);
        Obs = ObsSim(:,1);
        Sim = ObsSim(:,2);
        bias(oidx)=sum((Sim-Obs)./Obs)/length(Obs);
        sse(oidx) = sum(abs(Obs-Sim)./Obs)/length(Obs);
        NS(oidx) = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2);
        Vol(oidx)=sum(Sim)/sum(Obs);
        W(oidx)=size(ObsSim,1);
    end
end
if ~isempty(reservoir)
    length_calib=length(outlet)+length(reservoir);
else
    length_calib=length(outlet);
end

for oidx=1:length_calib
     if strcmp(AMALGAMPar.ponderation,'o')
        NStot=NStot+(1-NS(oidx))*W(oidx)/sum(W);
        NStotp=NStotp+NS(oidx)*W(oidx)/sum(W);
        VolR=VolR+abs(1-Vol(oidx))*W(oidx)/sum(W);
        VolRp=VolRp+Vol(oidx)*W(oidx)/sum(W);
        Biastot=Biastot+abs(bias(oidx))*W(oidx)/sum(W);
        Biastotp=Biastotp+bias(oidx)*W(oidx)/sum(W);
        SSEt=SSEt+sse(oidx)*W(oidx)/sum(W);
     else
        NStot=NStot+(1-NS(oidx))/length_calib;
        NStotp=NStotp+NS(oidx)/length_calib;
        VolR=VolR+abs(1-Vol(oidx))/length_calib;
        VolRp=VolRp+Vol(oidx)/length_calib;
        Biastot=Biastot+abs(bias(oidx))/length_calib;
        Biastotp=Biastotp+bias(oidx)/length_calib;
        SSEt=SSEt+sse(oidx)/length_calib;
     end
end

OF.sse = sse;
OF.bias=bias;
OF.Biastot=Biastot;
OF.Biastotp=Biastotp;
OF.sset=SSEt; 
OF.NS = NS;
OF.NStot=NStot;
OF.NStotp=NStotp;
OF.Vol=Vol;
OF.VolR=VolR;
OF.VolRp=VolRp;


