% This script can be used to calibrate SWAT parameters manually.
% clear all
close all
fclose all
clc
global n_sub file_id VarName
tic
t0=clock;
format long;
% Input Block .............................................................
sim_n=2;
%n_sub=36; % Number of subwatersheds in the project setup.

n_sub = 22; %STATSGO setup
outlets=[21]; % Number of outlets of interest in the project setup. 
%outlets=47; %statsgo
         % The last number should represent the watershed outlet.
out_id=[0,1,1,0,1,0,0,0,1,0,0,1,0,0]; % Outputs to be considered.
      % [bfr,sf,sed,orgn,orgp,no3n,nh4n,no2n,minp,solpst,sorpst,tp,tn,tpst]
IPRINT=1; % Calibration ID=1 for daily; 0 for monthly
% .........................................................................
disp(' .... MANUAL-CALIBRATION OF THE SWAT MODEL .... ') 
disp('   WRITTEN BY MAZDAK ARABI, PURDUE UNIVERSITY   ')
% Copy required files to the directory of simulations
% copyfile('..\sensin\*.*',['..\sim' num2str(sim_n)]); 
% copyfile('../P_files_new/*.*',['../sim' num2str(sim_n)]);
% % copyfile('..\swat\*.*',['..\sim' num2str(sim_n)]); 
% %copyfile('../bflow/*.*',['../sim' num2str(sim_n)]);
% copyfile('../user_inputs/*.*',['../sim' num2str(sim_n)]);
% %copyfile('..\swat\*.dat','..\sensin');
cd(['../sim' num2str(sim_n)])
disp('copying input files completed')
fid = fopen('par_file.prn','r');
c = textscan(fid,'%d%s%s%s%.7f%d%f%f','headerLines',2);
par_n = c{1};
x = c{5};
par_f = c{6};
file_id = id_func(n_sub);
par_alter(par_n,par_f,x);
!./swat
%objfun_f=objfun(n_sub,outlets,out_id,IPRINT);
%disp(objfun_f)  
%delete *.m *.p

%% Output Processing
% iVars: Provide all the output variables to be read from the .rch file
% 1. Flow
% 2. Organic Nitrogen (Org N)
% 3. Nitrate Nitrogen (NO3N)
% 4. Ammonia Nitrogen (NH3N)
% 5. Nitrite Nitrogen (NO2N)
% 6. Total Nitrogen (Org N + NO3N + NH3N + NO2N)
% 7. Organic Phosphorus (Org P)
% 8. Mineral Phosphorus (Min P)
% 9. Total Phosphorus (Org P + Min P)
% 10. Sediment 
% 11. Soluble Pesticide (SOLPST)
% 12. Sorbed Pesticide (SORPST)
% 13. Total Pesticide (SOLPST + SORPST)
% For e.g. if Flow, soluble pesticide, and total pesticide  are to be
% read and printed in the output iVars = [1 11 13];

VarName = {'Flow(cms)';'Org N(kg)';'NO3N(kg)';'NH4N(kg)';'NO2N(kg)';...
    'TN(kg)';'Org P(kg)';'Min P(kg)';'TP(kg)';'Sediment(tons)';...
    'Sol. Pst.(mg/L)';'Sor. Pst.(mg/L)';'Pesticide(mg/L)'};
iVars = [1 9];
start_year = 2001;
n_years = 5;
rchproc(iVars,n_sub,outlets,start_year,n_years);
calstats(outlets)
fclose all;
%plotLoadestSwat('TP',0)
cd ../P_files_new
timeelap = toc
! scp ../sim2/sim_daily21.dat swat@pasture.ecn.purdue.edu:~/copyfile
