function [SimRR] = cedar(Pars,Extra) 
global n_sub file_id outlet obsflow
x = (Pars);
file_id = id_func(n_sub);
par_alter(Extra.par_n,Extra.par_f,x);
!./sw2009nancy
iVars = [1];
rchproc(iVars,n_sub,outlet);
simdata = textread(['sim_daily' num2str(outlet) '.dat'],'','headerlines',1);
sse = sumsqr(obsflow-simdata(:,3));
%fid = fopen('../user_inputs/Runs.dat','a+');
%    fprintf(fid,'%.2f\t',sse);
%    for idx = 1:nPars
%    fprintf(fid,'%.3f\t',Pars(idx));
%    end
%    fprintf(fid,'\n');
%fclose(fid);
SimRR = simdata(:,3);
