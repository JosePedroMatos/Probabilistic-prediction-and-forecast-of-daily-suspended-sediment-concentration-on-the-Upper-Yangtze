% Plot the loadest estimated values along with the SWAT simulated values
clear all;clc;
simdata = textread('sim_daily1.dat','','headerlines',1);
simflow = simdata(:,3);
start_year=2001;start_month=1;start_day=1;

end_year=2005;end_month=12;end_day=31;

starting=datenum([num2str(start_month) '-' num2str(start_day) '-' ...
    num2str(start_year)]);
ending=datenum([num2str(end_month) '-' num2str(end_day) '-' ...
    num2str(end_year)]);

days_num=[starting:1:ending];
days_str=datestr(days_num);
for i=1:size(days_str,1)
    days_cell{i,1}=days_str(i,:);
end
%% Figure All In One
subplot(3,1,1)
[fdata,pdata,tdata] = nanfill('TP');
[ploadest,pconcest] = loadestproc('TP',0);
psim = simdata(:,5);

tp_m_l = zeros(12*(end_year - start_year + 1),1);

for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    tp_m_l(currmon+12*(curryr - start_year)) = ...
        tp_m_l(currmon + 12*(curryr - start_year)) + ploadest(dnow-starting+1);
    
end

tp_m_l_sim = zeros(12*(end_year - start_year + 1),1);
for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    tp_m_l_sim(currmon + 12*(curryr - start_year)) = ...
        tp_m_l_sim(currmon + 12*(curryr - start_year)) + ...
        psim(dnow-starting+1);%*simflow(dnow-starting+1)*86.4;
end

Obs = tp_m_l;
Sim = tp_m_l_sim;
Num = sum((Obs-mean(Obs)).*(Sim-mean(Sim)));
Den = sqrt(sum((Obs-mean(Obs)).^2)*sum((Sim - mean(Sim)).^2));
R_2_p = Num/Den
NSp = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2)

plot(tp_m_l/10^5,'-ko','LineWidth',2);%kg
hold on;
plot(tp_m_l_sim/10^5,'--+','LineWidth',2,'Color',[0.5 0.5 0.5]);%kg
set(gca,'YMinorTick','on','XMinorTick','on',...
    'LineWidth',2,'TickDir','out',...
    'TickLength',[0.03 0.07],...
    'FontWeight','bold','FontSize',12);
ylabel('TP (10^5 kg)');
text(10,1,['R^2 = ' num2str(0.77)]);
text(10,0.8,['R_{NS}^2 = ' num2str(0.56)]);
legend('Observed (Loadest)','Simulated (SWAT)');

subplot(3,1,2)
[fdata,pdata,tdata] = nanfill('TN');
[ploadest,pconcest] = loadestproc('TN',0);
psim = simdata(:,4);

tp_m_l = zeros(12*(end_year - start_year + 1),1);

for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    tp_m_l(currmon+12*(curryr - start_year)) = ...
        tp_m_l(currmon + 12*(curryr - start_year)) + ploadest(dnow-starting+1);
    
end

tp_m_l_sim = zeros(12*(end_year - start_year + 1),1);
for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    tp_m_l_sim(currmon + 12*(curryr - start_year)) = ...
        tp_m_l_sim(currmon + 12*(curryr - start_year)) + ...
        psim(dnow-starting+1);%*simflow(dnow-starting+1)*86.4;
end
Obs = tp_m_l;
Sim = tp_m_l_sim;
Num = sum((Obs-mean(Obs)).*(Sim-mean(Sim)));
Den = sqrt(sum((Obs-mean(Obs)).^2)*sum((Sim - mean(Sim)).^2));
R_2_p = Num/Den
NSp = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2)

plot(tp_m_l/10^5,'-ko','LineWidth',2);%kg
hold on;
plot(tp_m_l_sim/10^5,'--+','LineWidth',2,'Color',[0.5 0.5 0.5]);%kg
set(gca,'YMinorTick','on','XMinorTick','on',...
    'LineWidth',2,'TickDir','out','TickLength',[0.03 0.07],...
    'FontWeight','bold','FontSize',12);

ylabel('TN(10^5 kg)');
text(10,6.5,['R^2 = ' num2str(0.84)]);
text(10,5.5,['R_{NS}^2 = 0.64' num2str(0.66)]);

subplot(3,1,3)
[fdata,pdata,tdata] = nanfill('TSS');
[ploadest,pconcest] = loadestproc('TSS',0);
psim = simdata(:,6);

tp_m_l = zeros(12*(end_year - start_year + 1),1);

for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    tp_m_l(currmon+12*(curryr - start_year)) = ...
        tp_m_l(currmon + 12*(curryr - start_year)) + ploadest(dnow-starting+1);
end
tp_m_l = tp_m_l/1000;%convert sediment into tonnes
tp_m_l_sim = zeros(12*(end_year - start_year + 1),1);
for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    tp_m_l_sim(currmon + 12*(curryr - start_year)) = ...
        tp_m_l_sim(currmon + 12*(curryr - start_year)) + ...
        psim(dnow-starting+1);%*simflow(dnow-starting+1)*86.4;
end

Obs = tp_m_l;
Sim = tp_m_l_sim;
Num = sum((Obs-mean(Obs)).*(Sim-mean(Sim)));
Den = sqrt(sum((Obs-mean(Obs)).^2)*sum((Sim - mean(Sim)).^2));
R_2_p = Num/Den
NSp = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2)

plot(tp_m_l/10^3,'-ko','LineWidth',2);%1000 tons
hold on;
plot(tp_m_l_sim/10^3,'--+','LineWidth',2,'Color',[0.5 0.5 0.5]);%1000 tons
set(gca,'YMinorTick','on','XMinorTick','on',...
    'LineWidth',2,'TickDir','out',...
    'TickLength',[0.03 0.07],...
    'FontWeight','bold','FontSize',12);
xlabel('Month');
ylabel('SLD (10^3 tons)');
text(10,13,['R^2 = ' num2str(0.85)]);
text(10,11,['R_{NS}^2 = ' num2str(0.68)]);
samexaxis('abc','xmt','on','ytac','join','yld',1)





