function sub(subid,par_n,par_f,x)
subid=char(subid);
subid=[subid '.sub'];
CH_KI=x(par_n==33);
CH_NI=x(par_n==34);
CH_SI=x(par_n==35);

delete(subid);

fid1=fopen(['../sensin/' subid],'r');
fid2=fopen(subid,'w');

L=0;
while feof(fid1)==0;
      L=L+1;
      line=fgets(fid1);
      if L==29 && par_f(par_n==34)==1;
         fprintf(fid2,'%16.3f\t  %s\n',CH_NI,'| CH_N1 : Manning"s "n" value for the tributary channels');
      elseif L==26 && par_f(par_n==35)==1;
         CH_S=str2num(strtok(line))*(1+CH_SI); %#ok<ST2NM>
         fprintf(fid2,'%16.3f\t  %s\n',CH_S,'| CH_S1 : Average slope of tributary channel [m/m]');        
      elseif L==28 && par_f(par_n==33)==1;
         CH_KI=str2num(strtok(line))*(1+CH_KI); %#ok<ST2NM>
         fprintf(fid2,'%16.3f\t  %s\n',CH_KI,'| CH_K1 : Effective hydraulic conductivity in tributary channel [mm/hr]'); 
      else
         fprintf(fid2,'%s',line);
      end
end
fclose(fid1);
fclose(fid2);

return;
