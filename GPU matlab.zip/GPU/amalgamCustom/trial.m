%function trial(spoint,epoint)
global samplenum
t0=clock;samplenum=0;
% Input Blo/ck /. nb/. n- -- nb/nb/ nb/b/...........................................................
path_sim=12;
n_sub=177; % Number of subwatersheds in the project setup.
outlets=[157]; % Number of outlets of interest in the project setup. 
         % The last number should represent the watershed outlet.
out_id=[0,1,0,0,0,0,0,0,0,0,0,0,0,0]; % Outputs to be considered.
      % [bfr,sf,sed,orgn,orgp,no3n,nh4n,no2n,minp,solpst,sorpst,tp,tn,tpst]
IPRINT=1; % Calibration ID=1 for daily; 0 for monthly
% .........................................................................
 disp(' .... MANUAL-CALIBRATION OF THE SWAT MODEL .... ') 
 disp('   WRITTEN BY MAZDAK ARABI, PURDUE UNIVERSITY   ')
% Copy requied files to the directory of simulations
%copyfile('..\sensin\*.*',['..\sim' num2str(path_sim)]);
%copyfile('..\MatFiles\*.*',['..\sim' num2str(path_sim)]);
%copyfile('..\swat\*.*',['..\sim' num2str(path_sim)]);
%copyfile('..\bflow\*.*',['..\sim' num2str(path_sim)]);
%copyfile('..\user_inputs\*.*',['..\sim' num2str(path_sim)]);
%copyfile('..\swat\*.dat','..\sensin');
disp('copying input files completed')

% objfun_f=objfun(n_sub,outlets,out_id,IPRINT);
% disp(objfun_f)


load fullsample.mat
load minmax.txt
%%%% doing parameter alteration
load missing.txt
%for samplenum=spoint:epoint
for iNum = 1: size(missing,1);
    samplenum = missing(iNum);
    flag=minmax(:,4);
    par=sample(samplenum,:)';
    par_alter1(flag,par);
fid=fopen('par_file.prn')
a=textscan(fid,'%f %*s %*s %*s %f %f %*f %*f %*f','headerlines',2);
fclose(fid);
par_n=a{1};
par_f=a{3};
x=a{2};
par_alter(par_n,par_f,x)
disp('parameter alteration compleated')
%% Call the SWAT model
! ./swatath
copyfile('out86.txt',['../../output/out86_' num2str(samplenum),'.txt']);
copyfile('out83.txt',['../../output/out83_' num2str(samplenum),'.txt']);
copyfile('out71.txt',['../../output/out71_' num2str(samplenum),'.txt']);

    samplenum=samplenum+1;
end
%stats
% delete *.m *.p
fclose all
runtime1=fix(etime(clock,t0)/60);
runtime2=round((etime(clock,t0)/60-fix(etime(clock,t0)/60))*60);
disp(['runtime: ' num2str(runtime1) ' min     ' num2str(runtime2) ' sec'])
disp('simulations completed') 

