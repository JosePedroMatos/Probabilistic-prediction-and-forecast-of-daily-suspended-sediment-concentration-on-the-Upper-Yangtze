function plotLoadestSwat(ptype,figureflag)
% Plot the loadest estimated values along with the SWAT simulated values

[fdata,pdata,tdata] = nanfill(ptype);
[ploadest,pconcest] = loadestproc(ptype,0);
%% You will have to run the loadestformat and then run the loadest to get
%% the following coefficients
%% Read the simulated data: output from the SWAT model
simdata = textread('sim_daily1.dat','','headerlines',1);
if findstr(ptype,'TSS') > 0
    psim = simdata(:,6);
elseif findstr(ptype,'TP') > 0
    psim = simdata(:,5);
elseif findstr(ptype,'TN') > 0
    psim = simdata(:,4);
end

simflow = simdata(:,3);
%plot(simsed,'--r','LineWidth',2);
Obs = tdata(~isnan(tdata),1);
Sim = pconcest(~isnan(tdata),1);

Num = sum((Obs-mean(Obs)).*(Sim-mean(Sim)));
Den = sqrt(sum((Obs-mean(Obs)).^2)*sum((Sim - mean(Sim)).^2));
R_2_loadestconc = (Num/Den)^2
NSloadestconc = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2)
    start_year=2001;
    start_month=1;
    start_day=1;
    
    end_year=2005;
    end_month=12;
    end_day=31;
    
    starting=datenum([num2str(start_month) '-' num2str(start_day) '-' ...
        num2str(start_year)]);
    ending=datenum([num2str(end_month) '-' num2str(end_day) '-' ...
        num2str(end_year)]);
    days_num=[starting:1:ending];
    days_str=datestr(days_num);
%% Figure 1
if figureflag==1
    figure(1);
    plot(tdata,'ok','MarkerFaceColor','g','MarkerSize',10);
    set(gca,'YMinorTick','on','XMinorTick','on',...
        'LineWidth',2,'TickDir','out',...
        'TickLength',[0.03 0.07],...
        'FontWeight','bold','FontSize',12);
    hold on
    plot(pconcest,'-b','LineWidth',2);
    legend('Measured','Loadest');
    xlabel('Date');
    if findstr(ptype,'TSS') > 0
        ylabel('TSS (mg/L)');
        text(1500,170,['R^2 = ' num2str(R_2_loadestconc)]);
        text(1500,150,['R_{NS}^2 = ' num2str(NSloadestconc)]);
    elseif findstr(ptype,'TP') > 0
        ylabel('TP (mg/L)');
        text(1500,1,['R^2 = ' num2str(R_2_loadestconc)]);
        text(1500,1.2,['R_{NS}^2 = ' num2str(NSloadestconc)]);
    elseif findstr(ptype,'TN') > 0
        ylabel('TN (mg/L)');
        text(1500,4,['R^2 = ' num2str(R_2_loadestconc)]');
        text(1500,2,['R_{NS}^2 = ' num2str(NSloadestconc)]);
    end
    
    for i=1:size(days_str,1)
        days_cell{i,1}=days_str(i,:);
    end
    xticklabel_rotate(1:120:length(days_cell),45,days_cell(1:120:length(days_cell)));
    
end

tp_m_l = zeros(12*(end_year - start_year + 1),1);

for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    %     tp_m_l(currmon,curryr - start_year + 1) = ...
    %         tp_m_l(currmon,curryr - start_year + 1) + sload(dnow-starting+1);
    tp_m_l(currmon+12*(curryr - start_year)) = ...
        tp_m_l(currmon + 12*(curryr - start_year)) + ploadest(dnow-starting+1);
    
end


tp_m_l_sim = zeros(12*(end_year - start_year + 1),1);
for dnow = days_num
    currmon = month(dnow);
    curryr = year(dnow);
    tp_m_l_sim(currmon + 12*(curryr - start_year)) = ...
        tp_m_l_sim(currmon + 12*(curryr - start_year)) + ...
        psim(dnow-starting+1);%*simflow(dnow-starting+1)*86.4;
end
%% Figure 2
Obs = tp_m_l;
if findstr(ptype,'TSS') > 0
	Obs = tp_m_l/1000;
end

Sim = tp_m_l_sim;
Num = sum((Obs-mean(Obs)).*(Sim-mean(Sim)));
Den = sqrt(sum((Obs-mean(Obs)).^2)*sum((Sim - mean(Sim)).^2));
R_2_p = (Num/Den)^2
NSp = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2)

if figureflag == 1
    figure(2)
    if findstr(ptype,'TSS') > 0
        plot(tp_m_l/10^6,'-ko','LineWidth',2);%1000 tons
        hold on;
        plot(tp_m_l_sim/10^3,'--+','LineWidth',2,'Color',[0.5 0.5 0.5]);%1000 tons
    else
        plot(tp_m_l/10^5,'-ko','LineWidth',2);%kg
        hold on;
        plot(tp_m_l_sim/10^5,'--+','LineWidth',2,'Color',[0.5 0.5 0.5]);%kg
    end
    set(gca,'YMinorTick','on','XMinorTick','on',...
        'LineWidth',2,'TickDir','out',...
        'TickLength',[0.03 0.07],...
        'FontWeight','bold','FontSize',12);
    xlabel('Month');
    if findstr(ptype,'TSS') > 0
        ylabel('Monthly Sediment Load (10^3 tons)');
        text(40,10,['R^2 = ' num2str(NSp) ]);
        text(40,15,['R_{NS}^2 = ' num2str(R_2_p)]);
        
    elseif findstr(ptype,'TP') > 0
        ylabel('Monthly Phosphorus Load (10^5 kg)');
        text(40,10,'R^2 = 0.84');
        text(40,15,'R_{NS}^2 = 0.54');
    elseif findstr(ptype,'TN') > 0
        ylabel('Monthly Nitrogen Load (10^5 kg)');
        text(40,10,'R^2 = 0.84');
        text(40,15,'R_{NS}^2 = 0.64');
    end
    legend('Observed (Loadest)','Simulated (SWAT)');
end

save tp_m_l.out tp_m_l -ASCII

% [fhandle,msg] = jbfill(1:size(loadconcUP,1),loadconcUP',loadconcDOWN',...
%     [0 0 0],[0 0 0],0,.6)
%
% [fhandle,msg] = jbfill(1:size(loadkgpdUP,1),loadkgpdUP',loadkgpdDOWN',...
%     [0 0 0],[0 0 0],0,.6)



%% Figure 3 Figure for flow moved to calstats in ../ObsData
% if figureflag ==1
%     figure(3)
%     h1 = plot(simdata(:,3));
%     set(h1(1),'LineStyle','-','LineWidth',3,'Color',[0.5 0.5 0.5]);
%     hold on
%     plot(fdata(:,4),'-k','LineWidth',1);
%     text(1500,250,'R^2 = 0.80');
%     text(1500,200,'R_{NS}^2 = 0.58');
%     
%     set(gca,'YMinorTick','on','XMinorTick','on',...
%         'LineWidth',2,'TickDir','out',...
%         'TickLength',[0.03 0.07],...
%         'FontWeight','bold','FontSize',12);
%     xlabel('Date');
%     ylabel('Stream flow (m^3/s)');
%     xticklabel_rotate(1:120:length(days_cell),45,days_cell(1:120:length(days_cell)));
%     legend('Simulated','Observed');
% end
% Obs = fdata(:,4);
% Sim = simdata(:,3);
% Num = sum((Obs-mean(Obs)).*(Sim-mean(Sim)));
% Den = sqrt(sum((Obs-mean(Obs)).^2)*sum((Sim - mean(Sim)).^2));
% R_2_flow = (Num/Den)^2
% NSflow = 1 - sum((Obs - Sim).^2)/sum((Obs - mean(Obs)).^2)


