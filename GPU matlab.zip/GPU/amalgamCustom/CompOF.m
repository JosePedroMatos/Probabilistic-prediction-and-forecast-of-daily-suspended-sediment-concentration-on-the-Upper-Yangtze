function [newOF,newCg] = CompOF(x,AMALGAMPar,Measurement,ModelName,Extra)
% This function computes the objective function for each x value
global outlet parameter_all;
newOF = [];
% Evaluate each parameter combination and compute the objective functions
parameter=zeros(AMALGAMPar.N,AMALGAMPar.nobj*2+AMALGAMPar.n);
for ii = 1:AMALGAMPar.N,
    %%look in the parameter set already tested to see if already simulatied
    for i_par=1:AMALGAMPar.n
        M=parameter_all(x(ii,i_par)==parameter_all(:,AMALGAMPar.nobj*2+i_par),:);
        if isempty(M)
            break
        end
    end
    if isempty(M) %if ther is no similar parameter set
        % Call model to generate simulated data
        ModPred = '';
        % evalstr = ['ModPred = ',ModelName,'(x(ii,:),Extra);']; eval(evalstr);
        ModPred = vispa(x(ii,:),Extra);
        % Calculate the objective functions by comparing model predictions with
        % obs data
        OFall = CalcOF(ModPred,Measurement,Extra);
        %% Objective function that will be used in optimization   
        for i_name=1:length(AMALGAMPar.nameOF)
            if strcmp(AMALGAMPar.nameOF(i_name),'s')==1
                OF(i_name) = OFall.sset;
                OFprint(i_name) = OFall.sset;
            elseif strcmp(AMALGAMPar.nameOF(i_name),'v')==1
                OF(i_name) = OFall.VolR;
                OFprint(i_name) = OFall.VolR;
            elseif strcmp(AMALGAMPar.nameOF(i_name),'n')==1
                OF(i_name) = OFall.NStot;
                OFprint(i_name) = OFall.NStot;
            elseif strcmp(AMALGAMPar.nameOF(i_name),'c')==1
                OF(i_name) = OFall.sset+OFall.VolR;
                OFprint(i_name) = OFall.sset+4*OFall.VolR;
            else
                disp('Error in OF name')
            end
        end
        %% Write the objective function, NS, and parameter values in an output
        %% file
        nPars = Extra.nPars;
        fid = fopen('../user_inputs/RunsAmalgam.dat','a+');
        for i_OF=1:length(AMALGAMPar.nameOF)
            fprintf(fid,'%.2f\t',OFprint(i_OF));
        end
        for idx = 1:nPars
            fprintf(fid,'%.3f\t',x(ii,idx));
        end
        fprintf(fid,'\n');
        fclose(fid);
    else
        %% Write already calulated OF and parameters in AMALGAM.dat
        fid = fopen('../user_inputs/RunsAmalgam.dat','a+');
        for i_OF=1:length(AMALGAMPar.nameOF)
            fprintf(fid,'%.2f\t',M(1,i_OF));
            OFprint(i_OF)=M(1,i_OF);
            OF(i_OF)=M(1,i_OF+length(AMALGAMPar.nameOF));
        end
        nPars = Extra.nPars;
        for idx = 1:nPars
            fprintf(fid,'%.3f\t',x(ii,idx));
        end
        fprintf(fid,'\n');
        fclose(fid);
    end


    % Store the objective function values for each point
    newOF(ii,1:AMALGAMPar.nobj) = OF;

    % Define the contstraint violation
    newCg(ii,1) = 0;
    
    %Store the objective function and parameter value in global variable
    parameter(ii,:)=[OFprint OF x(ii,:)];

end;
parameter_all(end+1:end+AMALGAMPar.N,:)=parameter;