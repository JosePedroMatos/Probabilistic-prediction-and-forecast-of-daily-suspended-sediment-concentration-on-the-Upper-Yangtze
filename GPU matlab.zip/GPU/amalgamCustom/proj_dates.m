%This function determines the dates for output printing/summerization
function [out_dates]=proj_dates

% Determine the dates for output printing/summerization
fid=fopen('../sensin/file.cio','r');
L=0; % Counting variable
             
while feof(fid)==0;
    L=L+1;
    line=fgets(fid);
    if L==8
        NBYR = str2double(strtok(line));  % NBYR : Number of years simulated.
    elseif L==9
        IYR = str2double(strtok(line));   % IYR : Beginning year of simulation.
    elseif L==10
        IDAF = str2double(strtok(line));  % IDAF : Beginning julian day of simulation.
    elseif L==11
        IDAL = str2double(strtok(line));  % IDAL : Ending julian day of simulation.
    elseif L==60
        NYSKIP = str2double(strtok(line));% NYSKIP: number of years to skip output printing/summarization 
    end
end
if NYSKIP>0
    dates=datevec(datenum(IYR+NYSKIP,1,1):datenum(IYR+NBYR-1,1,IDAL));
else
    dates=datevec(datenum(IYR,1,IDAF):datenum(IYR+NBYR-1,1,IDAL));
end
yout=dates(:,1); % Vector of output printing/summarization years
mout=dates(:,2); % Vector of output printing/summarization months
dout=dates(:,3); % Vector of output printing/summarization days
out_dates=[yout,mout,dout];