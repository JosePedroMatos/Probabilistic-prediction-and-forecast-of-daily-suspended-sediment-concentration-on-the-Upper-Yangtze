list = 23
for i=list 
	fid1 = fopen('trial.m','r');
	fid2 = fopen(['sim' num2str((i-1)*1000+1) '_' num2str(i*1000) '/sim/trial.m'],'w');
	for k = 1:9
	temp = fgets(fid1);
	fprintf(fid2,'%s',temp);
	end
	fprintf(fid2,'spoint = %d\n',(i-1)*1000+1);
	fprintf(fid2,'epoint = %d\n',i*1000);
	while feof(fid1) == 0
		temp = fgets(fid1);
		fprintf(fid2,'%s',temp);
	end
	fclose(fid1);
	fclose(fid2);
end


	


