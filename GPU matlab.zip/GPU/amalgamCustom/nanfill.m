function [fdata,pdata,tdata] = nanfill(ptype)

%% [fdata,pdata,tdata] = nanfill(ptype)
%
% fdata: flow data for the days when available. Usually it is available for
% every day from the USGS gauging station. (in m^3/s)
%
% pdata: pollutant data for the days when available. Usually it is not a
% continuous data and only a few days of data will be available in a month
%
% tdata: pollutant data for all the days for which the flow is available.
% Usually the flow is available for all the days, therefore this variable
% takes NaN for the days when the pollutant data is not available. 
% 
% tdata can be used to plot the pollutant load along with the stream flow
% or the LOADEST estimated daily pollutant loads
% 
% ptype is the type of pollutant. It can be TP, TN, or TSS for which the
% appropriate data file (for e.g. 300kokomoTP.csv) is provided in
% the same folder.

%% Read TSS measured data from IDEM in mg/L

pdata_all = textread(['SForkWildcat' ptype '.csv'],'','delimiter',',',...
    'headerlines',0);
pdata = pdata_all(:,1:4);

%% Read flow data in cms 
% fdata -> [year month day flow(cms)]
fdata = textread('obs_daily1.csv','','delimiter',',',...
    'headerlines',1);


%% tdata contains the continuous TSS data for the range of streamflow data.
%% Missing days take 'NaN'
for i = 1:size(fdata,1)
    sdata = find(pdata(:,1) == fdata(i,1) & ...
        pdata(:,2) == fdata(i,2) & pdata(:,3) == fdata(i,3));
    if size(sdata,1) > 0
        tdata(i,1) = mean(pdata(sdata,end));
    else 
        tdata(i,1) = NaN;
    end
end

%% Add a column to the data array for flow (ft^3/s) for days when the
%% measured TSS data is available and the rest of the days take 'NaN'
for i = 1:size(pdata,1)
    sdata = find(fdata(:,1) == pdata(i,1) & ...
        fdata(:,2) == pdata(i,2) & fdata(:,3) == pdata(i,3));
    if size(sdata,1) > 0
        pdata(i,5) = fdata(sdata,end);
    else 
        pdata(i,5) = NaN;
    end
end
