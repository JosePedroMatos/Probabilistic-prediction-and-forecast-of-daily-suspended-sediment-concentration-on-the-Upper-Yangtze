ObsDataAll = textread('obs_daily26.csv','','headerlines',1,'delimiter',',');
StartDate = find(ObsDataAll(:,1) == 2006 & ObsDataAll(:,2) == 1 & ...
    ObsDataAll(:,3) == 1);
EndDate = find(ObsDataAll(:,1) == 2007 & ObsDataAll(:,2) == 12 & ...
    ObsDataAll(:,3) == 31);
ObsData = ObsDataAll(StartDate:EndDate,:);
fid1 = fopen('a26.dat','w');
for idx = 1:size(ObsData,1)
    
    daynum = datenum(ObsData(idx,1:3)) - datenum(ObsData(idx,1),1,1) + 1;
    tflowstr = sprintf('%12.3E\n',ObsData(idx,4));
    tnodatastr = sprintf('  %12.3E\n',-99);
    
    flowstr = tflowstr([1:9 11:12]);
    nodatastr = tnodatastr([1:9 11:12]);
    fprintf(fid1,'%5d%5d   %s',ObsData(idx,1),daynum,flowstr)
    for didx = 1:21
        fprintf(fid1,'%s',nodatastr);
    end
    fprintf(fid1,'\n');
end
fclose(fid1);