function chm(hruid,hru_lnd,par_n,par_f,x)
hruid=char(hruid);
hru_str=[hruid '.chm'];
LABP=x(par_n==10);
ORGN=x(par_n==11);
ORGP=x(par_n==12);
SOLN=x(par_n==13);

if strcmp(hru_lnd,'Row Crops')==1 
    delete(hru_str);
    fid1=fopen(['../sensin/' hru_str],'r');
    fid2=fopen(hru_str,'w');
    L=0;
    while feof(fid1)==0;
        L=L+1;
        line=fgets(fid1);
        if L==6 && par_f(par_n==10)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ...
                ' Soil labile P [mg/kg]    :',LABP,0,0,0,0,0,0,0,0,0);
        elseif L==7 && par_f(par_n==12)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ... 
                ' Soil organic P [mg/kg]   :',ORGP,0,0,0,0,0,0,0,0,0);
        elseif L==5 && par_f(par_n==11)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ...
                ' Soil organic N [mg/kg]   :',ORGN,0,0,0,0,0,0,0,0,0);
        elseif L==4 && par_f(par_n==13)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ...
                ' Soil NO3 [mg/kg]         :',SOLN,0,0,0,0,0,0,0,0,0);
        else
            fprintf(fid2,'%s',line);
        end 
    end
    fclose(fid1);
    fclose(fid2);
end

if strcmp(hru_lnd,'Pasture/Hay')==1
    delete(hru_str);
    fid1=fopen(['..\sensin\' hru_str],'r');
    fid2=fopen(hru_str,'w');
    L=0;
    while feof(fid1)==0;
        L=L+1;
        line=fgets(fid1);
        if L==6 && par_f(par_n==10)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ...
                ' Soil labile P [mg/kg]    :',LABP*0.25,0,0,0,0,0,0,0,0,0);
        elseif L==7 && par_f(par_n==12)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ... 
                ' Soil organic P [mg/kg]   :',ORGP*0.25,0,0,0,0,0,0,0,0,0);
        elseif L==5 && par_f(par_n==11)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ...
                ' Soil organic N [mg/kg]   :',ORGN*0.25,0,0,0,0,0,0,0,0,0);
        elseif L==4 && par_f(par_n==13)==1;
            fprintf(fid2,'%s%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f%12.3f\n', ...
                ' Soil NO3 [mg/kg]         :',SOLN*0.25,0,0,0,0,0,0,0,0,0);
        else
            fprintf(fid2,'%s',line);
        end 
    end
    fclose(fid1);
    fclose(fid2);
end
return;
