function stats = calstats(sub)
obsdata_all = textread(['obs_daily' num2str(sub) '.csv'],'',...
    'delimiter',',','headerlines',1);
simdata_all = textread(['sim_daily' num2str(sub) '.dat'],'','headerlines',1);
%StartDate = simdata(1,2) -1 + datenum(simdata(1,1),1,1);
StartDate = datenum(2001,1,1);
EndDate = simdata_all(end,2) -1 + datenum(simdata_all(end,1),1,1);
% EndDate = simdata(end,2) -1 + datenum(simdata(end,1),1,1);
SimStart = find(simdata_all(:,1) == year(StartDate) & ...
  simdata_all(:,2) == (datenum(StartDate)-datenum(year(StartDate),1,1)+1));
SimEnd = find(simdata_all(:,1) == year(EndDate) & ...
  simdata_all(:,2) == (datenum(EndDate)-datenum(year(EndDate),1,1)+1));
            
ObsStart = find(obsdata_all(:,1) == year(StartDate) & ...
                obsdata_all(:,2) == month(StartDate) & ...
                obsdata_all(:,3) == day(StartDate));
ObsEnd = find(obsdata_all(:,1) == year(EndDate) & ...
                obsdata_all(:,2) == month(EndDate) & ...
                obsdata_all(:,3) == day(EndDate));
            
            
obsdata = obsdata_all(ObsStart:ObsEnd,:);
simdata = simdata_all(SimStart:SimEnd,:);
StartYear = year(StartDate);
k = 1;
for Yidx = year(StartDate):year(EndDate)
    for Midx = 1:12
        Mcounter = (Yidx-StartYear)*12 + Midx;
        MonSimData(Mcounter) = 0;
        MonObsData(Mcounter) = 0;
        for Didx = 1:max(max(calendar(Yidx,Midx)))
            MonSimData(Mcounter) = MonSimData(Mcounter) + simdata(k,3);
            MonObsData(Mcounter) = MonObsData(Mcounter) + obsdata(k,4);
            k = k + 1;
        end
    end
end
        
    

stats.R2flow = min(min((corrcoef(simdata(:,3),obsdata(:,4))).^2))
stats.R2NSflow = 1 - sum((obsdata(:,4) - simdata(:,3)).^2)/sum((obsdata(:,4) - mean(obsdata(:,4))).^2)
stats.R2flowMon = min(min((corrcoef(MonSimData,MonObsData)).^2))
stats.R2NSflowMon = 1 - sum((MonObsData - MonSimData).^2)/sum((MonObsData - mean(MonObsData)).^2)
% Precipitation
% poption = 2;
% if poption == 1
%     data_all = textread('Pcp.csv','','delimiter',',');
%     DataStart = find(data_all(:,1) == 2001 & data_all(:,2) == 1);
%     DataEnd = find(data_all(:,1) == 2007 & data_all(:,2) == 365);
%     data = data_all(DataStart:DataEnd,:);
%     pcpdata = data(:,9);
% elseif poption == 2
%     data_all = textread('pcp1.csv','','delimiter',',','headerlines',3);
%     DataStart = find(data_all(:,1) == 2001 & data_all(:,2) == 1);
%     DataEnd = find(data_all(:,1) == 2007 & data_all(:,2) == 365);
%     data = data_all(DataStart:DataEnd,:);
%     pcpdata = mean(data(:,3),2);
% end
% %% Plotting
% figure1 = figure;
% days_num=StartDate:1:EndDate;
% days_str=datestr(days_num);
% for i=1:size(days_str,1)
% days_cell{i,1}=days_str(i,:);
% end
% 
% % set(gca,'YMinorTick','on','XMinorTick','on','LineWidth',2,'TickDir','out',...
% %     'TickLength',[0.01 0.05],...
% %     'FontWeight','bold','FontSize',12);
% % set(gca,'YLim',[0 10]);
% legend('Observed','Simulated');
% 
% hold on
% plot(simdata(:,3),'-','LineWidth',2,'Color',[0.4 .4 .4]);
% plot(obsdata(:,4),'k-','LineWidth',1);
% set(gca,'Box','off','XLim',[0 length(days_cell)])
% xticklabel_rotate(1:120:length(days_cell),45,days_cell(1:120:length(days_cell)));
% legend('Simulated','Observed');
% ylabel('Stream flow (m^3/s)');
% 
% 
% axes1 = axes('Parent',figure1,'YAxisLocation','right','XAxisLocation','top',...
%     'YDir','reverse','YLim',[0 800],'Color','none');
% 
% hold('all');
% bar(pcpdata,'Parent',axes1);
% ylabel('Precipitation (mm)');
% xlim([0 length(days_cell)]);
% % xticklabel_rotate(1:120:length(days_cell),90,days_cell(1:120:length(days_cell)));
% text(800,150,'R^2 = 0.76');
% text(800,200,'R_{NS}^2 = 0.75');
% xticklabel_rotate(1:120:length(days_cell),45,days_cell(1:120:length(days_cell)));
% figure(2)
% plot(MonObsData,'b-','LineWidth',1);
% hold on
% plot(MonSimData,'r-');


