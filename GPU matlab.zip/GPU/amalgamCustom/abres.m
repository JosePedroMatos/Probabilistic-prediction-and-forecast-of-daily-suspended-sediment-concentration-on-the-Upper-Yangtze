function abres(par_n,par_f,x)

delete('ab.par')

data=importdata('../sensin/ab.par');
par_number=64;
a=1;
for i_line=par_number:3:par_number+(size(data,1)-1)*3
    if par_f(par_n==i_line+1)==1 ||par_f(par_n==i_line+2)==1 ||par_f(par_n==i_line+2)==1;
        if par_f(par_n==i_line+1)==1
            data(a,1)=x(par_n==i_line+1);
        end
        if par_f(par_n==i_line+2)==1
            data(a,2)=x(par_n==i_line+2);
        end
        if par_f(par_n==i_line+3)==1
            data(a,3)=x(par_n==i_line+3);
        end 
    end
    if i_line==par_number
        fid2=fopen('ab.par','w');
    else
        fid2=fopen('ab.par','a');
    end
    fprintf(fid2,'%10.0f  %8.2f  %11.2f\r\n',data(a,1), data(a,2),data(a,3));
    fclose(fid2);
    a=a+1;
end
return;
