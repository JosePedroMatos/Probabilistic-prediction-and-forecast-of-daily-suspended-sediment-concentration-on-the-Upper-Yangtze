list = 1:7
for i=list 
copyfile('*.m',['sim' num2str((i-1)*1000+1) '_' num2str(i*1000) '/sim/']);
end


	


