function hru(hruid,par_n,par_f,x)
hruid=char(hruid);
hru_str=[hruid '.hru'];
ESCO=x(par_n==18);
OV_N=x(par_n==19);
RSDIN=x(par_n==20);
SLOPE=x(par_n==21);
SLSUBBSN=x(par_n==22);
EPCO = x(par_n==52);
DEP_IMP = x(par_n==61);
CANMX = x(par_n==64);
delete(hru_str);

fid1=fopen(['../sensin/' hru_str],'r');
fid2=fopen(hru_str,'w');

L=0;
while feof(fid1)==0;
    L=L+1;
    line=fgets(fid1);
    if L==3 && par_f(par_n==22)==1;
        str1=strtok(line);
        SLSUBBSN=str2double(str1)*(1+SLSUBBSN);
        fprintf(fid2,'%16.3f\t  %s\n',SLSUBBSN,'| SLSUBBSN : Average slope length [m]');
    elseif L==4 && par_f(par_n==21)==1;
        str1=strtok(line);
        SLOPE=str2double(str1)*(1+SLOPE);
        fprintf(fid2,'%16.3f\t  %s\n',SLOPE,'| HRU_SLP : Average slope stepness [m/m]');
    elseif L==5 && par_f(par_n==19)==1;
        fprintf(fid2,'%16.3f\t  %s\n',OV_N,'| OV_N : Manning"s "n" value for overland flow'); 
    elseif L==10 && par_f(par_n==18)==1;
        fprintf(fid2,'%16.3f\t  %s\n',ESCO,'| ESCO : Soil evaporation compensation factor'); 
    elseif L==11 && par_f(par_n==52)==1;
        fprintf(fid2,'%16.3f\t  %s\n',EPCO,'| EPCO : Plant uptake compensation factor');
elseif L==12 && par_f(par_n==20)==1;
        fprintf(fid2,'%16.3f\t  %s\n',RSDIN,'| RSDIN : Initial residue cover [kg/ha]'); 
elseif L==9 && par_f(par_n==64)==1;
        fprintf(fid2,'%16.3f\t  %s\n',CANMX,'| CANMX : Maximum canopy storage [mm]'); 
elseif L==24 && par_f(par_n==61)==1;
        fprintf(fid2,'%16.3f\t  %s\n',DEP_IMP,'| DEP_IMP : Depth to impervious layer in soil profile [mm]'); 
    else
        fprintf(fid2,'%s',line);
    end
end
fclose(fid1);
fclose(fid2);
return;
