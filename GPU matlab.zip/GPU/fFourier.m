function yF=fFourier(x, y, period, fourierCoefs);
    A = zeros(size(x,1),fourierCoefs);
    A(:,1) = 1;
    w0 = 2*pi/period;
    for i0=2:(fourierCoefs-1)/2
        A(:,i0) = cos(w0*(i0-1)*x);
        A(:,i0+(fourierCoefs-1)/2) = sin(w0*(i0-1)*x);
    end
    coeff = A\y;

    x=[1:period]';
    A = zeros(size(x,1),fourierCoefs);
    A(:,1) = 1;
    for i1=2:(fourierCoefs-1)/2
        A(:,i1) = cos(w0*(i1-1)*x);
        A(:,i1+(fourierCoefs-1)/2) = sin(w0*(i1-1)*x);
    end
    yF=A*coeff;

end