function [output,fullParGen,fullObjVals,ParSet] = AMALGAM_bands(AMALGAMPar,ModelName,ParRange,Fpareto,Extra,varargin);
% function [output,ParGen,ObjVals,ParSet] = AMALGAM(AMALGAMPar,ModelName,ParRange,Measurement,Extra,Fpareto);
% ------------------ The AMALGAM multiobjective optimization algorithm ------------------------ %
%                                                                                               %
% This general purpose MATLAB code is designed to find a set of parameter values that defines   %
% the Pareto trade-off surface corresponding to a vector of different objective functions. In   %
% principle, each Pareto solution is a different weighting of the objectives used. Therefore,   %
% one could use multiple trials with a single objective optimization algorithms using diferent  %
% values of the weights to find different Pareto solutions. However, various contributions to   %
% the optimization literature have demonstrated that this approach is rather inefficient. The   %
% AMALGAM code developed herein is designed to find an approximation of the Pareto solution set %
% within a single optimization run. The AMALGAM method combines two new concepts,               %
% simultaneous multimethod search, and self-adaptive offspring creation, to ensure a fast,      %
% reliable, and computationally efficient solution to multiobjective optimization problems. 	%
% This method is called a multi-algorithm, genetically adaptive multiobjective, or AMALGAM, 	%
% method, to evoke the image of a procedure that blends the attributes of the best available 	%
% individual optimization algorithms.                                                           %
%                                                                                               %
% This algorithm has been described in:                                                         %
%                                                                                               %
% J.A. Vrugt, and B.A. Robinson, Improved evolutionary optimization from genetically adaptive   %
%    multimethod search, Proceedings of the National Academy of Sciences of the United States   %
%    of America, 104, 708 - 711, doi:10.1073/pnas.0610471104, 2007.                             %
%                                                                                               %
% J.A. Vrugt, B.A. Robinson, and J.M. Hyman, Self-Adaptive MultiMethod Search For Global        %
%    Optimization in Real-Parameter Spaces, IEEE Transactions on Evolutionary Computation,      %
%    1-17, 10.1109/TEVC.2008.924428, In Press, 2009                                             %
%                                                                                               %
% For more information please read:                                                             %
%                                                                                               %
% J.A. Vrugt, H.V. Gupta, L.A. Bastidas, W. Bouten, and S. Sorooshian, Effective and efficient  %
%    algorithm for multi-objective optimization of hydrologic models, Water Resources Research, %
%    39(8), art. No. 1214, doi:10.1029/2002WR001746, 2003.                                      %
%                                                                                               %
% G.H. Schoups, J.W. Hopmans, C.A. Young, J.A. Vrugt, and W.W.Wallender, Multi-objective        %
%    optimization of a regional spatially-distributed subsurface water flow model, Journal      %
%    of Hydrology, 20 - 48, 311(1-4), doi:10.1016/j.jhydrol.2005.01.001, 2005.                  %
%                                                                                               %
% J.A. Vrugt, P.H. Stauffer, T. W�hling, B.A. Robinson, and V.V. Vesselinov, Inverse modeling   %
%    of subsurface flow and transport properties: A review with new developments, Vadose Zone   %
%    Journal, 7(2), 843 - 864, doi:10.2136/vzj2007.0078, 2008.                                  %
%                                                                                               %
% T. W�hling, J.A. Vrugt, and G.F. Barkle, Comparison of three multiobjective optimization      %
%    algorithms for inverse modeling of vadose zone hydraulic properties, Soil Science Society  %
%    of America Journal, 72, 305 - 319, doi:10.2136/sssaj2007.0176, 2008.                       %
%                                                                                               %
% T. W�hling, and J.A. Vrugt, Combining multi-objective optimization and Bayesian model         %
%    averaging to calibrate forecast ensembles of soil hydraulic models, Water Resources        %
%    Research, 44, W12432, doi:10.1029/2008WR007154, 2008.                                      %
%                                                                                               %
%                                                                                               %
% Copyright (c) 2008, Los Alamos National Security, LLC                                         %
%                                                                                               %
% All rights reserved.                                                                          %
%                                                                                               %
% Copyright 2008. Los Alamos National Security, LLC. This software was produced under U.S.      %
% Government contract DE-AC52-06NA25396 for Los Alamos National Laboratory (LANL), which is     %
% operated by Los Alamos National Security, LLC for the U.S. Department of Energy. The U.S.     %
% Government has rights to use, reproduce, and distribute this software.                        %
%                                                                                               %
% NEITHER THE GOVERNMENT NOR LOS ALAMOS NATIONAL SECURITY, LLC MAKES A NY WARRANTY, EXPRESS OR  %
% IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE. If software is modified to    %
% produce derivative works, such modified software should be clearly marked, so as not to       %
% confuse it with the version available from LANL.                                              %
%                                                                                               %
% Additionally, redistribution and use in source and binary forms, with or without              %
% modification, are permitted provided that the following conditions are met:                   %
% � Redistributions of source code must retain the above copyright notice, this list of         %
%   conditions and the following disclaimer.                                                    %
% � Redistributions in binary form must reproduce the above copyright notice, this list of      %
%   conditions and the following disclaimer in the documentation and/or other materials         %
%   provided with the distribution.                                                             %
% � Neither the name of Los Alamos National Security, LLC, Los Alamos National Laboratory, LANL %
%   the U.S. Government, nor the names of % its contributors may be used to endorse or promote  %
%   products derived from this software without specific prior written permission.              %
%                                                                                               %
% THIS SOFTWARE IS PROVIDED BY LOS ALAMOS NATIONAL SECURITY, LLC AND CONTRIBUTORS "AS IS" AND   %
% ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES      %
% OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL LOS %
% ALAMOS NATIONAL SECURITY, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, %
% SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF   %
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        %
% HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT %
% (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,       %
% EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                            %
%                                                                                               %
%                                                                                               %
% AMALGAM code developed by Jasper A. Vrugt, Center for NonLinear Studies (CNLS), LANL          %
%                                                                                               %
% Written by Jasper A. Vrugt: vrugt@lanl.gov                                                    %
%                                                                                               %
% Version 0.5:   June 2006                                                                      %
% Version 1.0:   January 2009    Cleaned up source code and implemented 4 test example problems %
%                                                                                               %
% --------------------------------------------------------------------------------------------- %

    alternate = 1;
    if (alternate)
        AMALGAMPar.N = round(AMALGAMPar.N/2);
        AMALGAMPar.ndraw = AMALGAMPar.ndraw+rem(AMALGAMPar.ndraw, AMALGAMPar.N);
    end

    %% First run
    try
        % Initialize algorithmic variables and other properties
        [AMALGAMPar,Extra,output,Bounds,ParSet,V] = InitVariables(AMALGAMPar,Extra);

        % Sample AMALGAMPar.N points in the parameter space
        if isfield(Extra,'Initial') && ~isempty(Extra.Initial)
            ParGen = Extra.Initial(1:AMALGAMPar.N,:);
        else
            ParGen = LHSU(ParRange.minn,ParRange.maxn,AMALGAMPar.N);
        end
        if isfield(Extra,'bPoint') && ~isempty(Extra.bPoint)
            tmp0=rand(size(ParGen,1),1)<0.05;
            tmp1=repmat(Extra.bPoint,ceil(AMALGAMPar.N/size(Extra.bPoint,1)),1);
            tmp1=tmp1(1:size(ParGen,1),:);
            ParGen(tmp0,:)=tmp1(tmp0,:);
        end

        % Calculate objective function values for each of the AMALGAMPar.N points
        modelFunction=[];
        evalc(['modelFunction=@' ModelName]);
        [ObjVals] = modelFunction(ParGen',varargin{[5 1 2]});
        ObjVals = ObjVals';
        Cg = zeros(size(ObjVals,1),1);

        % Ranking and CrowdDistance Calculation
        [Ranking, CrowdDist] = CalcRank(ObjVals, Bounds, Cg);

        % Define the current iteration value
        Iter = AMALGAMPar.N;

        % Store current population in ParSet
        ParSet(1:AMALGAMPar.N,1:AMALGAMPar.n + AMALGAMPar.nobj + 1) = [ParGen Cg ObjVals];

        if isfield(Extra,'Initial') && ~isempty(Extra.Initial) && (alternate)
            Iter = AMALGAMPar.N*2;    
        end

        % Define counter
        counter = 1;
    catch err
        rethrow(err);
    end

    % Initiate plots
        % Pareto front
    fig=585;
    figure(fig);
    cla;
    colorSet=gray(12);
    colorSet=flipud(colorSet(1:10,:));

    tmp=strfind(varargin{5}.evalFuns{1},')');
    xlabel(['Non-exceedance fraction:' varargin{5}.evalFuns{1}(tmp(1)+1:end)]);
    tmp=strfind(varargin{5}.evalFuns{2},')');
    ylabel([varargin{5}.evalFuns{2}(tmp(1)+1:end)]);
    title('Training Pareto front');
    
    figure(586);
    cla;
    ObjValsVal = modelFunction(ParGen',varargin{[5 3 4]})';
    tmp=[varargin([5 1 2]), 'setPersistentOnly', true];
    modelFunction(ParGen',tmp{:});
    tmp=strfind(varargin{5}.evalFuns{1},')');
    xlabel(['Non-exceedance fraction:' varargin{5}.evalFuns{1}(tmp(1)+1:end)]);
    tmp=strfind(varargin{5}.evalFuns{2},')');
    ylabel([varargin{5}.evalFuns{2}(tmp(1)+1:end)]);
    title('Test Pareto front');
    
    if ~exist(Extra.SaveFolder,'dir')
        mkdir(Extra.SaveFolder);
    end
    
    fullObjVals=ObjVals;
    fullObjValsVal=ObjValsVal;
    fullParGen=ParGen;

    % Now iterate
    old = [];
    doesPSO = ismember('PSO',Extra.Alg);
    while (Iter < AMALGAMPar.ndraw+AMALGAMPar.N),

        % Step 1: Now determine Pbest and Nbest for Particle Swarm Optimization
        tmp = ParSet(1:Iter,1:end);
        if rem(counter,2) == 0 && (alternate)
            tmp(:,end-AMALGAMPar.nobj+1) = 1-tmp(:,end-AMALGAMPar.nobj+1);
        end
        [pBest,nBest] = SelBest(Ranking,tmp,AMALGAMPar,Extra);

        % Step 2: Generate offspring
        [NewGen,V,Itot] = GenChild(ParGen,ObjVals,Ranking,CrowdDist,Cg,V,pBest,nBest,AMALGAMPar,ParRange,Extra);

        % Step 2b: Check whether parameters are in bound
        [NewGen] = CheckPars(NewGen,ParRange,Extra.BoundHandling);

        % Step 3: Compute Objective Function values offspring
        [ChildObjVals] = modelFunction(NewGen',varargin{[5]});
        ChildObjVals=ChildObjVals';
        ChildCg=zeros(size(ChildObjVals,1),1);

        if rem(counter,2) == 0  && (alternate)
            ChildObjVals(:,1) = 1-ChildObjVals(:,1);
        end

        %%%%%% Switch exceedance/non-exceedance objective and save alternate solutions.
        try
            if (alternate)
                [~, sortedIdsParentsPrev] = sort(ObjVals(:,1), 'ascend');      %Best in the previous run
                [~, sortedIdsChildrenPrev] = sort(ChildObjVals(:,1), 'ascend');

                if isempty(old)
                    sortedIdsParentsNext = flipdim(sortedIdsParentsPrev,1);
                    sortedIdsChildrenNext = flipdim(sortedIdsChildrenPrev,1);

                    if isfield(Extra,'Initial') && ~isempty(Extra.Initial)
                        old.ParGen = Extra.Initial((AMALGAMPar.N+1):end,:);
                        [old.ObjVals] = modelFunction(old.ParGen',varargin{[5 1 2]});
                        old.ObjVals = old.ObjVals';
                        old.ObjVals(:,1) = 1-old.ObjVals(:,1);
                        [~, sortedIdsParentsNext] = sort(ObjVals(:,1), 'ascend');
                        old.ParGen = old.ParGen(sortedIdsParentsNext,:);
                        old.ObjVals = old.ObjVals(sortedIdsParentsNext,:);

                        ParSet((AMALGAMPar.N+1):AMALGAMPar.N*2,1:AMALGAMPar.n + AMALGAMPar.nobj + 1) = [old.ParGen Cg old.ObjVals];

                        old.NewGen = NewGen(sortedIdsChildrenNext,:);
                        old.ChildObjVals = ChildObjVals(sortedIdsChildrenNext,:);
                        old.Itot = Itot([sortedIdsParentsNext; AMALGAMPar.N+sortedIdsChildrenNext],:);
                        old.Cg = Cg(sortedIdsParentsNext,:);
                        old.ChildCg = ChildCg(sortedIdsChildrenNext,:);
                        if (doesPSO)
                            old.V = V(sortedIdsChildrenNext,:,:);
                        end

                        old.ChildObjVals(:,1) = 1-old.ChildObjVals(:,1);
                    else
                        old.ParGen = ParGen(sortedIdsParentsNext,:);
                        old.ObjVals = ObjVals(sortedIdsParentsNext,:);
                        old.NewGen = NewGen(sortedIdsChildrenNext,:);
                        old.ChildObjVals = ChildObjVals(sortedIdsChildrenNext,:);
                        old.Itot = Itot([sortedIdsParentsNext; AMALGAMPar.N+sortedIdsChildrenNext],:);
                        old.Cg = Cg(sortedIdsParentsNext,:);
                        old.ChildCg = ChildCg(sortedIdsChildrenNext,:);
                        if (doesPSO)
                            old.V = V(sortedIdsChildrenNext,:,:);
                        end
                        old.ObjVals(:,1) = 1-old.ObjVals(:,1);
                        old.ChildObjVals(:,1) = 1-old.ChildObjVals(:,1);
                    end            
                end

                new.ParGen = ParGen(sortedIdsParentsPrev,:);
                new.NewGen = NewGen(sortedIdsChildrenPrev,:);
                new.ObjVals = ObjVals(sortedIdsParentsPrev,:);
                new.ChildObjVals = ChildObjVals(sortedIdsChildrenPrev,:);
                new.Itot = Itot([sortedIdsParentsPrev; AMALGAMPar.N+sortedIdsChildrenPrev],:);
                new.Cg = Cg(sortedIdsParentsPrev,:);
                new.ChildCg = ChildCg(sortedIdsChildrenPrev,:);
                if (doesPSO)
                    new.V = V(sortedIdsChildrenPrev,:,:);
                end

                %invert objectives for the next run
                ParSet(1:Iter,end-AMALGAMPar.nobj+1) = 1-ParSet(1:Iter,end-AMALGAMPar.nobj+1);
                ObjVals(:,1) = 1-ObjVals(:,1);
                ChildObjVals(:,1) = 1-ChildObjVals(:,1);

                toReplace = 1:max([0 min([AMALGAMPar.N round((2+randn(1)*0.05)*AMALGAMPar.N)])]);
                toReplaceChildren = 1:max([0 min([AMALGAMPar.N round((0.9+randn(1)*0.05)*AMALGAMPar.N)])]);
    %             toReplaceChildren = 1:AMALGAMPar.N;

                toRemoveParents = sortedIdsParentsPrev(toReplace);
                toRemoveChildren = sortedIdsChildrenPrev(toReplaceChildren);

                ParGen(toRemoveParents,:) = old.ParGen(toReplace,:);
                NewGen(toRemoveChildren,:) = old.NewGen(toReplaceChildren,:);
                ObjVals(toRemoveParents,:) = old.ObjVals(toReplace,:);
                ChildObjVals(toRemoveChildren,:) = old.ChildObjVals(toReplaceChildren,:);
                Itot([toRemoveParents; AMALGAMPar.N+toRemoveChildren],:) = old.Itot([toReplace AMALGAMPar.N+toReplaceChildren],:);
                Cg(toRemoveParents,:) = old.Cg(toReplace,:);
                ChildCg(toRemoveChildren,:) = old.ChildCg(toReplaceChildren,:);
                if (doesPSO)
                    V(toRemoveChildren,:,:) = old.V(toReplaceChildren,:,:);
                end

                old = new;
            end
        catch err
            rethrow(err);
        end

        % Step 4: Now merge parent and child populations and generate new one
        [ParGen,ObjVals,Ranking,CrowdDist,Iout,Cg] = CreateNewPop(ParGen,NewGen,ObjVals,ChildObjVals,Itot,Cg,ChildCg,ParRange,Bounds);

        % Step 5: Determine the new number of offspring points for individual algorithms
        [AMALGAMPar] = DetN(Iout,AMALGAMPar);

        % Step 6: Append the new points to ParSet
        ParSet(Iter+1:Iter+AMALGAMPar.N,1:end) = [ParGen Cg ObjVals];
        if rem(counter,2) == 0 && (alternate)
            ParSet(Iter+1:Iter+AMALGAMPar.N,end-AMALGAMPar.nobj+1) = 1-ParSet(Iter+1:Iter+AMALGAMPar.N,end-AMALGAMPar.nobj+1);
        end

        % Step 7: Update counter
        counter = counter + 1;

        % Step 8: Update Iteration
        Iter = Iter + AMALGAMPar.N;
        
        % Step 9: Plot
        try
            tmp=2.^[0:10];
            tmp(tmp>Extra.SavePeriod)=[];
            if rem(ceil(counter/2),Extra.SavePeriod)==0 || ismember(ceil(counter/2),tmp);
                [hES, hESt]=earlyStopping();
                
                ObjValsVal = modelFunction(ParGen',varargin{[5 3 4]})';
                if rem(counter,2) == 0 && (alternate)
                    ObjValsVal(:,1) = 1-ObjValsVal(:,1);
                end
                tmp=[varargin([5 1 2]), 'setPersistentOnly', true];
                modelFunction(ParGen',tmp{:});
                
                if ~(alternate)
                    fullObjVals=[];
                    fullObjValsVal=[];
                    fullParGen=[];
                end
                if ~(alternate) || rem(counter,2) == 0
                    tmp = ObjVals;
                    tmp(:,1) = 1-tmp(:,1);
                    fullObjVals=[fullObjVals; tmp];
                    tmp = ObjValsVal;
                    tmp(:,1) = 1-tmp(:,1);
                    fullObjValsVal=[fullObjValsVal; tmp];
                    fullParGen=[fullParGen; ParGen];
                    
                    plotPareto(585, fullObjVals, colorSet);
                    plotPareto(586, fullObjValsVal, colorSet);
 
                    %Agreement between validation and training in terms of
                    %non-exceedance ratio and average 2nd parameter
                    [sortedObjVals] = sortrows(fullObjVals,1);
                    uniqueObjVals = unique(sortedObjVals(:,1));
                    dominatedHyperspace=[uniqueObjVals nan(size(uniqueObjVals,1),size(sortedObjVals,2)-1)];
                    for i0=1:size(uniqueObjVals,1)
                        for i1=2:size(sortedObjVals,2)
                            dominatedHyperspace(i0,i1)=min(fullObjVals(fullObjVals(:,1)==uniqueObjVals(i0,1),i1));
                        end
                    end
                    tmp=[0; (dominatedHyperspace(1:end-1,1)+dominatedHyperspace(2:end,1))/2; 1];
                    vicinity=tmp(2:end,1)-tmp(1:end-1,1);

                    [sortedObjValsVal] = sortrows(fullObjValsVal,1);
                    uniqueObjValsVal = unique(sortedObjValsVal(:,1));
                    dominatedHyperspaceVal=[uniqueObjValsVal nan(size(uniqueObjValsVal,1),size(sortedObjValsVal,2)-1)];
                    for i0=1:size(uniqueObjValsVal,1)
                        for i1=2:size(sortedObjValsVal,2)
                            dominatedHyperspaceVal(i0,i1)=min(fullObjValsVal(fullObjValsVal(:,1)==uniqueObjValsVal(i0,1),i1));
                        end
                    end
                    tmp=[0; (dominatedHyperspaceVal(1:end-1,1)+dominatedHyperspaceVal(2:end,1))/2; 1];
                    vicinityVal=tmp(2:end,1)-tmp(1:end-1,1);
                
                    %Various fitness metrics
                    if counter==2
                        bands=[0.01 0.025 0.15 0.25 0.35 0.65 0.75 0.85 0.975 0.99];
                        bandWidth=0.025;
                        bandRanges=[bands-bandWidth;bands+bandWidth];
                        for i0=1:size(bands,2)
                            if bandRanges(1,i0)<0
                                bandRanges(1,i0)=0;
                                bandRanges(2,i0)=2*bands(i0);
                            end
                            if bandRanges(2,i0)>1
                                bandRanges(2,i0)=1;
                                bandRanges(1,i0)=-1+2*bands(i0);
                            end
                        end
                        
                        figure(fig+4);
                        [results, bandResults]=computeBands(fullParGen, modelFunction, bandRanges, bands, varargin{:});
                        
                    else
                        figure(fig+4);
                        [results, bandResults]=computeBands(fullParGen, modelFunction, bandRanges, bands, varargin{:});
                        
                        traResults = [];
                        traResults.alpha = results.perf.alpha.tra;
                        traResults.xi = results.perf.xi.tra;
                        traResults.pi = results.perf.piAbs.tra;
                        traResults.cprs = results.perf.cprs.tra;
                        
                        tesResults = [];
                        tesResults.alpha = results.perf.alpha.tes;
                        tesResults.xi = results.perf.xi.tes;
                        tesResults.pi = results.perf.piAbs.tes;
                        tesResults.cprs = results.perf.cprs.tes;
                        
                        disp('Training: ');
                        disp(traResults);
                        
                        disp('Test: ');
                        disp(tesResults);
                    end
                    
                    figure(590)
                    shadePlotBands(varargin{2}, bandResults(1:size(varargin{2},2),:));
                    title('Training');
                    figure(591)
                    shadePlotBands(varargin{4}, bandResults(size(varargin{2},2)+1:end,:));
                    title('Validation');
                else
                    fullObjVals=ObjVals;
                    fullObjValsVal=ObjValsVal;
                    fullParGen=ParGen;
                end
            end
            drawnow;
            if get(hESt,'Value')==1
                close(hES);
                return;
            end
        catch err
            rethrow(err);
        end
    end
    close(hES);
    
    function plotPareto(fig, objectives, colorSetFig)
        figure(fig);

        hold all;
        set(gca, 'ColorOrder', colorSetFig);
        if size(objectives,2)<3
            plot(objectives(:,1), objectives(:,2), '.');
        end
        hold off;
    end
end