function output=netSim(inputs,iIW,iLW,ib1,ib2,ifunLay1,ifunLay2)
    tmp=ifunLay1(iIW*inputs+repmat(ib1,1,size(inputs,2)));
    output=ifunLay2(iLW*tmp+repmat(ib2,1,size(inputs,2)));
end