%Mean squared error with Lp regularization
function performance = mseLp(observed, simulated, weights, model)
    if isfield(model,'noRegularization') && ~isempty(model.noRegularization)
        eval(['weights(' model.noRegularization ')=[];']);
    end
    performance = sum((observed-simulated).^2)/length(observed)+...
        model.regParam*(sum(abs(weights).^model.regExponent)).^(1/model.regExponent);
end
